// 362
// marks
// Mark Salisbury
// P362A12.cpp

#include <iostream.h>

void main(void) {

  cout << "1 2 3 4" << endl;
  
  cout << "1 " << "2 " << "3 " << "4 " << endl;
 
  cout << "1 ";
  cout << "2 ";
  cout << "3 ";
  cout << "4 " << endl;
}