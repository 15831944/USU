char *number;
number= new char[2] = "0\0";