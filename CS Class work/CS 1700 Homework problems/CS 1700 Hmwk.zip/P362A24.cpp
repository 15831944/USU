// 362
// marks
// Mark Salisbury
// P362A24.cpp

#include <iostream.h>

void main(void){
	
	cout << "number\tsquare\tcube" << endl;
	cout << "0\t0\t0" << endl;
	cout << "1\t1\t1" << endl;
	cout << "2\t4\t8" << endl;
	cout << "3\t9\t27" << endl;
	cout << "4\t16\t64" << endl;
	cout << "5\t25\t125" << endl;
	cout << "6\t36\t216" << endl;
	cout << "7\t49\t343" << endl;
	cout << "8\t64\t512" << endl;
	cout << "9\t81\t729" << endl;
	cout << "10\t100\t1000" << endl;

}
