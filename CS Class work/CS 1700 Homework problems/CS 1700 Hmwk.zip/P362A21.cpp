// 362
// marks
// Mark Salisbury
// P362A21.cpp

#include <iostream.h>

void main(void){
	
	cout << "*********         ***           *           *     " << endl;
	cout << "*       *       *     *        ***         * *    " << endl;
	cout << "*       *      *       *      *****       *   *   " << endl;
	cout << "*       *      *       *        *        *     *  " << endl;
	cout << "*       *      *       *        *       *       * " << endl;
	cout << "*       *      *       *        *       *       * " << endl;
	cout << "*       *      *       *        *        *     *  " << endl;
	cout << "*       *      *       *        *         *   *   " << endl;
	cout << "*       *       *     *         *          * *    " << endl;
	cout << "*********         ***           *           *     " << endl;
}
