// PIN
// username
// Name
// filename

#include <iostream.h>

void main(void) {
int a,b;
  cout << "Enter an integer: ";
  cin >> a;
  cout << "Enter an integer: ";
  cin >>b;
  cout << "The sum of these numbers is: " << a + b;
  cout << endl << "The product of these numbers is: " << a * b;
  cout << endl << "The difference of these numbers is: " << a - b;
  cout << endl << "The quotient of these numbers is: " << a / b << endl;
}