/*Preparation

   1.Read: pp. 147 - 154, 168 - 172 in Deitel & Deitel 
   2.Complete Worksheet 5 printable form 

Objectives

   1.User defined functions 
   2.File I/O 

Programming

   1.Create an input text file containing the following data:

     5.562
     3.110
     8.696

   2.Write a function called average that accepts three doubles as parameters and returns their average. 

   3.Write a prototype for average. 

   4.Write a main function that reads three doubles from a file and calculates their average using average. The main program should write the average to standard
     output. */
