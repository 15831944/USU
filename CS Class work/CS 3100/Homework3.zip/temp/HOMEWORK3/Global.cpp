
#include "stdafx.h"
#include "Homework 3.h"

// this file is for miscellaneous functions that don't belong in any
// particular class

CString ValueToString(double value, int dPlaces = 2){
	CString prefix = "";
	if (value < 0){
		prefix = "-";
		value *= -1;
	}
	for (int i = 0; i < dPlaces; i++) value *= 10;
	int nCopy = (int)value;
	if (nCopy == 0)
		prefix = "";

	CString StringValue;
	int dPlace = 0;
	do 
	{
		StringValue.Insert(0,char(nCopy % 10 + '0'));
		nCopy /= 10;
		dPlace++;
		if (dPlace == dPlaces){
			StringValue.Insert(0,'.');
			if (nCopy == 0)
				StringValue.Insert(0,'0');
		}
	} 
	while (nCopy > 0 || dPlace < dPlaces);//while (nCopy > 0);
	
	return prefix + StringValue;
}