// ProcessScheduleSimulator.h: interface for the CProcessScheduleSimulator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROCESSSCHEDULESIMULATOR_H__4C7FE20E_93B5_11D4_909E_00A0CC5C952D__INCLUDED_)
#define AFX_PROCESSSCHEDULESIMULATOR_H__4C7FE20E_93B5_11D4_909E_00A0CC5C952D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Queue.h"

class CProcess;

class CProcessScheduleSimulator  
{
public:
	BOOL IsLimit;
	int ProcLimit;
	int currentTime;
	int MaxProcInQueue;
	double AverageResponseTime;
	double Efficiency;
	double AverageWaitTime;
	double AverageCompletionTime;
	CProcess * Process[100];
	CProcess * currentProcess;
	Queue<CProcess *> ProcessQueue;
	Queue<CProcess *> NewProcessQueue;
	Queue<CProcess *> MLQueue[4];
	int currQueue;
	int queueTimes[4];
	int currPID;
	int TotalIdleTime;
	int TotalCompletionTime;
	int TotalResponseTime;
	int SwitchTime;
	int TotalWaitTime;
	int TotalExecutionTime;
	int ProcessorTime;
	int ActiveProcesses;
	int ScheduleType;
	int TotalProcesses;
	int LoadedProcesses;
	int Quantum;

	CProcessScheduleSimulator();
	virtual ~CProcessScheduleSimulator();
	void StartCPU(CString FileName, int q, int sType, BOOL IsLimit, int ProcLimit);
	void ScheduleProcesses();
	void ExecuteCurrentProcess();
	void WaitIdleProcesses();
};

#endif // !defined(AFX_PROCESSSCHEDULESIMULATOR_H__4C7FE20E_93B5_11D4_909E_00A0CC5C952D__INCLUDED_)
