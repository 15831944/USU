// Homework 3Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "Homework 3.h"
#include "Homework 3Dlg.h"

#include "ProcessScheduleSimulator.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define AVG_COMPLETION_TIME		0
#define AVG_RESPONSE_TIME		1
#define AVG_WAIT_TIME			2
#define EFFICIENCY				3
#define MAX_PROC_INQUEUE		4

extern CString ValueToString(double value, int dPlaces = 2);

/////////////////////////////////////////////////////////////////////////////
// CHomework3Dlg dialog

CHomework3Dlg::CHomework3Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHomework3Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHomework3Dlg)
	m_Quantum = 0;
	m_FileName = _T("");
	m_sType = -1;
	m_maxProc = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHomework3Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHomework3Dlg)
	DDX_Control(pDX, IDC_MAXPROC, m_maxProcEdit);
	DDX_Control(pDX, IDC_RESULTS, m_Results);
	DDX_Text(pDX, IDC_QUANTUM, m_Quantum);
	DDV_MinMaxInt(pDX, m_Quantum, 1, 100);
	DDX_Text(pDX, IDC_TEST_FILE, m_FileName);
	DDX_CBIndex(pDX, IDC_STYPE, m_sType);
	DDX_Text(pDX, IDC_MAXPROC, m_maxProc);
	DDV_MinMaxInt(pDX, m_maxProc, 1, 10000);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHomework3Dlg, CDialog)
	//{{AFX_MSG_MAP(CHomework3Dlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON3, OnBrowse)
	ON_BN_CLICKED(IDC_BUTTON2, OnParseFile)
	ON_BN_CLICKED(IDC_LIMITED, OnLimited)
	ON_BN_CLICKED(IDC_UNLIMITED, OnUnlimited)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHomework3Dlg message handlers

BOOL CHomework3Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_Results.InsertColumn(0,"Statistics    ",LVCFMT_LEFT,150);
	m_Results.InsertColumn(1,"Round Robin   ",LVCFMT_LEFT,150);
	m_Results.InsertColumn(2,"Multi Level Feedback Queue ",LVCFMT_LEFT,150);
	m_Results.InsertItem(AVG_COMPLETION_TIME,"Average Completion Time");
	m_Results.InsertItem(AVG_RESPONSE_TIME,"Average Response Time");
	m_Results.InsertItem(AVG_WAIT_TIME,"Average Wait Time");
	m_Results.InsertItem(EFFICIENCY,"Efficiency");
	m_Results.InsertItem(MAX_PROC_INQUEUE,"Max Processes in Queue");
	m_Results.SetColumnWidth(0,LVSCW_AUTOSIZE_USEHEADER);
	m_Results.SetColumnWidth(1,LVSCW_AUTOSIZE_USEHEADER);
	m_Results.SetColumnWidth(2,LVSCW_AUTOSIZE_USEHEADER);
	m_Quantum = 2;
	m_sType = 0;
	m_procsLimited = FALSE;
	m_maxProc = 100;
	OnProcessLimit();
	UpdateData(FALSE);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHomework3Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CHomework3Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CHomework3Dlg::OnBrowse() 
{
	UpdateData();
	// TODO: Add your control notification handler code here
	CFileDialog fDlg(TRUE,".dat",NULL,OFN_HIDEREADONLY|OFN_FILEMUSTEXIST,"Text Files (*.tst)|*.txt|Data Files (*.dat)|*.dat|All Files (*.*)|*.*|",NULL);
	char title[] = "Choose a data file to parse";
	fDlg.m_ofn.lpstrFileTitle = title;
	fDlg.DoModal();
	m_FileName = fDlg.GetPathName();
	UpdateData(FALSE);
}

void CHomework3Dlg::OnParseFile() 
{
	// TODO: Add your control notification handler code here
	if (UpdateData())
	{
		int nItem = 0;
		CString s;
		CProcessScheduleSimulator cpuTest;
		CWaitCursor waitCursor;
		int testType = m_sType + 1;
		
		cpuTest.StartCPU(m_FileName,m_Quantum,testType, m_procsLimited, m_maxProc);
		s = ValueToString(cpuTest.AverageCompletionTime);
		m_Results.SetItemText(AVG_COMPLETION_TIME,testType,s);
		s = ValueToString(cpuTest.AverageResponseTime);
		m_Results.SetItemText(AVG_RESPONSE_TIME,testType,s);
		s = ValueToString(cpuTest.AverageWaitTime);
		m_Results.SetItemText(AVG_WAIT_TIME,testType,s);
		s = ValueToString(cpuTest.Efficiency * 100.0);
		s += "%";
		m_Results.SetItemText(EFFICIENCY,testType,s);
		s = ValueToString(cpuTest.MaxProcInQueue);
		m_Results.SetItemText(MAX_PROC_INQUEUE,testType,s);
		
	}
	
}

void CHomework3Dlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

void CHomework3Dlg::OnLimited() 
{
	// TODO: Add your control notification handler code here
	m_procsLimited = TRUE;
	OnProcessLimit();
}

void CHomework3Dlg::OnUnlimited() 
{
	// TODO: Add your control notification handler code here
	m_procsLimited = FALSE;
	OnProcessLimit();
}

void CHomework3Dlg::OnProcessLimit()
{
	((CButton*)GetDlgItem(IDC_LIMITED))->SetCheck(m_procsLimited);
	((CButton*)GetDlgItem(IDC_UNLIMITED))->SetCheck(!m_procsLimited);
	m_maxProcEdit.EnableWindow(m_procsLimited);
	if (m_procsLimited)
		m_maxProcEdit.SetFocus();

}
