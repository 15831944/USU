// ProcessScheduleSimulator.cpp: implementation of the CProcessScheduleSimulator class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Homework 3.h"
#include "ProcessScheduleSimulator.h"

#include "Process.h"
#include <fstream.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

// assumptions:  total switch time is incremented when a new process 
// is loaded, i.e. switching takes place.  it is also incremented 
// when the cpu goes idle for a cycle.
// The efficiency is :
//  total execution time / (total switch time + total idle time + total execution time)
// this is wrong because the timer is not incremented when this happens, and hence
// total switch time + total idle time + total execution time != total running time.
//
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProcessScheduleSimulator::CProcessScheduleSimulator()
{
	
}

CProcessScheduleSimulator::~CProcessScheduleSimulator()
{

}

void CProcessScheduleSimulator::StartCPU(CString FileName, int q, int sType, BOOL IsL, int L)
{
	IsLimit = IsL;
	ProcLimit = L;
	ifstream fin(FileName);
	Quantum = q;
	currentProcess = NULL;
	ScheduleType = sType;
	int NextArrivalTime = 0;
	int BurstLength;
	// allows up to 100 processes to be running concurrently.
	bool EndOfFile = false;
	TotalCompletionTime = 0;
	TotalExecutionTime = 0;
	TotalWaitTime = 0;
	TotalIdleTime = 0;
	TotalResponseTime = 0;
	SwitchTime = 0;
	CProcess * ptrTempProc = NULL;
	LoadedProcesses = 0;  // number of processes either in queue and currently loaded (1 or 0)
	ActiveProcesses = 0;  // number of processes that have arrived whose time has not expired
	TotalProcesses = 0;   // number of processes that have arrived 
	currPID = -1;
	ProcessorTime = 0;
	 // stuff for MLFQ
	currQueue = 0;
	queueTimes[0] = Quantum;
	queueTimes[1] = queueTimes[0] * 2;
	queueTimes[2] = queueTimes[1] * 2;
	queueTimes[3] = queueTimes[2] * 2;

	MaxProcInQueue = 0.0;

	fin >> NextArrivalTime >> BurstLength;
	int DoneReading = fin.eof();

	for ( currentTime = 0; LoadedProcesses > 0 || !DoneReading; currentTime++)
	{
		// check to see if a new process has arrived
		while (NextArrivalTime == currentTime && !DoneReading){
			ptrTempProc = new CProcess(BurstLength, TotalProcesses, currentTime);
			NewProcessQueue.enqueue( ptrTempProc );
			TotalProcesses++;
			ActiveProcesses++;
			fin >> NextArrivalTime >> BurstLength;
			DoneReading = fin.eof();
			//if (TotalProcesses == 3)
			//	DoneReading = TRUE;
		}
		
		// determine if we should load a new process.  If yes, load it.
		ScheduleProcesses();
		
		// execute current process.
		ExecuteCurrentProcess();
		
		// increment waiting and response times for inactive processes.
		WaitIdleProcesses();
	}
	AverageCompletionTime = double(TotalCompletionTime) / double(TotalProcesses);
	AverageWaitTime = double(TotalWaitTime) / double(TotalProcesses);
	Efficiency = double(TotalExecutionTime) / double(SwitchTime + TotalIdleTime + TotalExecutionTime);
	AverageResponseTime = double(TotalResponseTime) / double(TotalProcesses);

	fin.close();
}

void CProcessScheduleSimulator::WaitIdleProcesses()
{
	CProcess * ptrTempProc = NULL;
	switch (ScheduleType){
	case (ROUND_ROBIN):{
		QueueNode<CProcess *> *ptrNode = ProcessQueue.GetHeadPtr();
		while (ptrNode)//for (int i = 0; i < LoadedProcesses - 1 && ptrNode; i++)
		{
			ptrTempProc = ptrNode->data;
			if (!ptrTempProc)
				AfxMessageBox("Error",MB_OK);
			ptrTempProc->Wait();
			ptrNode = ptrNode->nextPtr;
		}
	} break;
	case (MLFQ):{
		for (int i = 0; i < 4; i++)
		{
			QueueNode<CProcess *> *ptrNode = MLQueue[i].GetHeadPtr();
			while (ptrNode)//for (int i = 0; i < LoadedProcesses - 1 && ptrNode; i++)
			{
				ptrTempProc = ptrNode->data;
				if (!ptrTempProc)
					AfxMessageBox("Error",MB_OK);
				ptrTempProc->Wait();
				ptrNode = ptrNode->nextPtr;
			}
		}
	} break;
	}
}

void CProcessScheduleSimulator::ExecuteCurrentProcess()
{
	if (currentProcess) // if there is a process to be executed
	{
		ProcessorTime++;
		if (currentProcess->Execute() == 0){
			// ADJUST STATS BEFORE DELETING PROCESS
			TotalResponseTime += currentProcess->ResponseTime;
			TotalWaitTime += currentProcess->WaitTime;
			TotalCompletionTime += currentTime - currentProcess->StartTime+1;
			delete currentProcess;
			LoadedProcesses--;
			ActiveProcesses--;
			currentProcess = NULL;
		}
		TotalExecutionTime++;
	}
	else
	{
		TotalIdleTime++;
	}
}

void CProcessScheduleSimulator::ScheduleProcesses()
{
	switch (ScheduleType){
	case (ROUND_ROBIN):
	{
	
		if ( currentProcess && ProcessorTime == Quantum )
		{
			// put the current process back in the queue.
			ProcessQueue.enqueue(currentProcess);
			currentProcess = NULL;
		}

		while ( LoadedProcesses < ActiveProcesses && 
			    (!IsLimit || LoadedProcesses < ProcLimit))
		{
			// Load the newly arrived process
			CProcess * tempPtr = NewProcessQueue.dequeue();
			if (!tempPtr)
				AfxMessageBox("Error at line 146",MB_OK);
			ProcessQueue.enqueue( tempPtr );
			LoadedProcesses++;
			if ( LoadedProcesses > MaxProcInQueue )
				MaxProcInQueue = (double)LoadedProcesses;
		}

		if ( currentProcess == NULL )
		{
			ProcessorTime = 0;
			// let's find a new process and switch to it.  
			// the last one is out of the cpu.
			currentProcess = ProcessQueue.dequeue();
			if (currentProcess && currPID != currentProcess->pID)
			{ // we are now running a new process.  increment switch time.
				SwitchTime++;
				currPID = currentProcess->pID;
			}
		}
		
	} break;
	case (MLFQ):
	{
		if ( currentProcess && ProcessorTime == queueTimes[currQueue] ) 
		{
			// put the current process back in a lower queue if it expires
			if (currQueue < 3)
				currQueue++;
			MLQueue[currQueue].enqueue(currentProcess);
			currentProcess = NULL;
		}
		if ( currentProcess && LoadedProcesses < ActiveProcesses && 
			 (!IsLimit || LoadedProcesses < ProcLimit) ) 
		{
			// if a new job comes in put the process back in the same level queue
			MLQueue[currQueue].enqueue(currentProcess);
			currentProcess = NULL;
		}

		while ( LoadedProcesses < ActiveProcesses && 
			    (!IsLimit || LoadedProcesses < ProcLimit))
		{
			// Load the newly arrived process
			CProcess * tempPtr = NewProcessQueue.dequeue();
			if (!tempPtr)
				AfxMessageBox("Error at line 146",MB_OK);
			MLQueue[0].enqueue( tempPtr );
			LoadedProcesses++;
			if ( LoadedProcesses > MaxProcInQueue )
				MaxProcInQueue = (double)LoadedProcesses;
		}

		if ( currentProcess == NULL )
		{
			ProcessorTime = 0;
			// let's find a new process and switch to it.  
			// the last one is out of the cpu.
			for (int i = 0; i < 4 && !currentProcess; i++)
				currentProcess = MLQueue[i].dequeue();
			currQueue = i - 1;	
				
			if (currentProcess && currPID != currentProcess->pID)
			{ // we are now running a new process.  increment switch time.
				SwitchTime++;
				currPID = currentProcess->pID;
			}
		}

	} break;
	}

}
