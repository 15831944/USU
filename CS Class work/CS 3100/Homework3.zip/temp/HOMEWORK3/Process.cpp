// Process.cpp: implementation of the CProcess class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Homework 3.h"
#include "Process.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProcess::CProcess()
{

}

CProcess::CProcess(int BurstLength, int pid, int stime)
{
	TimeRemaining = BurstLength;
	pID = pid;
	StartTime = stime;
	HasExecuted = false;
	WaitTime = 0;
	ResponseTime = 0;
}

CProcess::~CProcess()
{

}

int CProcess::Execute()
{
	TimeRemaining--;
	HasExecuted = true;
	return TimeRemaining;
}

void CProcess::Wait()
{
	if (!HasExecuted)
		ResponseTime++;
	WaitTime++;
}
