// Process.h: interface for the CProcess class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROCESS_H__4C7FE211_93B5_11D4_909E_00A0CC5C952D__INCLUDED_)
#define AFX_PROCESS_H__4C7FE211_93B5_11D4_909E_00A0CC5C952D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CProcess
{
public:
	int StartTime;
	int ResponseTime;
	int WaitTime;
	void Wait();
	int Execute();
	bool HasExecuted;
	int pID;
	int TimeRemaining;
	CProcess();
	CProcess(int BurstLength, int pID, int StartTime);
	virtual ~CProcess();

};

#endif // !defined(AFX_PROCESS_H__4C7FE211_93B5_11D4_909E_00A0CC5C952D__INCLUDED_)
