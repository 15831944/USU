//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SocketStarter.rc
//
#define IDD_SOCKETSTARTER_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_ACTIVE               129
#define IDD_DIALOG_PASSIVE              130
#define IDD_DIALOG_DATAGRAM             131
#define IDD_DIALOG_WATCH                132
#define IDC_RADIO_ACTIVE                1000
#define IDC_RADIO_PASSIVE               1001
#define IDC_RADIO_DATAGRAM              1002
#define IDC_EDIT_ACTIVEIP               1003
#define IDC_EDIT_ACTIVEPORT             1004
#define IDC_EDIT_PASSIVEPORT            1005
#define IDC_EDIT_DG_REMOTEIP            1006
#define IDC_EDIT_DG_REMOTEPORT          1007
#define IDC_EDIT_DG_LOCALPORT           1008
#define IDC_BUTTON_SEND                 1009
#define IDC_EDIT_DATARCVD               1010
#define IDC_EDIT_DATA2SEND              1011
#define IDC_ACCEPT_STATUS               1012
#define IDC_EDIT_STATUS                 1013
#define IDC_EDIT1                       1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
