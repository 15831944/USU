//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestPackage.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TESTPACKAGE_DIALOG          102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_TEST_BUTTON                 1001
#define IDC_TEST_HITRACKDB              1002
#define IDC_TEST_DSTRING                1002
#define IDC_TEST_HIBABYTABLE            1003
#define IDC_TEST_HIMOTHERTABLE          1004
#define IDC_TEST_IMPORT_ENGINE          1005
#define IDC_TEST_EVENT                  1005
#define IDC_TEST_QUICKMATCHDEF          1006
#define IDC_TEST_CONFIGURATION          1006
#define IDC_TEST_QUICKMATCHDEFRS        1007
#define IDC_TEST_STRDUP                 1007
#define IDC_TEST_TRANFERFILE            1008
#define IDC_TEST_COMCHANNEL             1008
#define IDC_TEST_VSBIRTH                1009
#define IDC_TEST_UNUSED4                1009
#define IDC_TEST_SERVER_COM_CHANNEL     1009
#define IDC_TEST_VSBIRTHFIELDDEFRS      1010
#define IDC_TEST_UNUSED5                1010
#define IDC_TEST_CLIENT_COM_CHANNEL     1010
#define IDC_MESSAGE_LOG                 1011
#define IDC_TEST_UNUSED6                1012
#define IDC_TEST_UNUSED7                1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
