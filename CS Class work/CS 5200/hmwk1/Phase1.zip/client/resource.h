//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by client.rc
//
#define IDD_CLIENT_DIALOG               102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_CONFIG_DLG                  129
#define IDD_EVENT_LIST                  130
#define IDD_ADD_EVENT_DLG               131
#define IDC_LIST_EVENTS                 1000
#define IDC_ADD_EVENT                   1001
#define IDC_ID                          1003
#define IDC_EDIT_FILENAME               1004
#define IDC_DESC                        1005
#define IDC_NOTE                        1006
#define IDC_DATE                        1007
#define IDC_DURATION                    1008
#define IDC_LOCATION                    1009
#define IDC_START                       1010
#define IDC_END                         1011
#define IDC_QUERY                       1012
#define IDC_LIST                        1013
#define IDC_NAME                        1014
#define IDC_DATE_PICKER                 1015
#define IDC_TIME_PICKER                 1016
#define IDC_START_DATE                  1017
#define IDC_END_DATE                    1018
#define IDC_LIST_VIEW                   1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
