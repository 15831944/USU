/*
 * MemObject.java
 *
 * Created on November 30, 2001, 2:50 PM
 */



/**
 *
 * @author  marks
 * @version 
 */

import LinkedList;
import java.io.*;

public class MemObject extends Object {

    /** Creates new MemObject */
    
    public MemObject() 
    {
        referenceCount = 0;
    }
    public MemObject(String vName)
    {
        referenceCount = 1;
        ReferenceNames.InsertAtBack(vName);
    }

    private int referenceCount;

    private LinkedList ReferenceNames;
   
    public boolean ReferenceExists(String vName)
    {
         // parse through the linked list, looking for a reference of name vName
         ReferenceNames.BeginEnumeration();
         Object nodeData;
         while ((nodeData = ReferenceNames.GetNextData()) != null)
         {
              if (vName.equals(nodeData))
                   return true;
         }
         return false;
    }
    public void RemoveReference(String vName)
    {
         // parse through the linked list, looking for a reference of name vName
         if (ReferenceNames.DeleteNode(vName))
             referenceCount--;
    }
    public boolean AddReference(String vName)
    {
        if (!ReferenceExists(vName))
        {
            ReferenceNames.InsertAtBack(vName);
            referenceCount++;
            return true;
        }
        else 
            return false;
    }
    public int GetReferenceCount()
    {
        return referenceCount;
    }
    public void PrintInfo(PrintWriter out)
    {
        String referenceName;
        out.println("Reference Count = " + GetReferenceCount());
        ReferenceNames.BeginEnumeration();
        while ((referenceName = (String)ReferenceNames.GetNextData()) != null)
        {
            out.println("   Reference Name = " + referenceName);
        }
    }
}