/*
 * HeapSimulator.java
 *
 * Created on November 29, 2001, 11:04 AM
 */



/**
 *
 * @author  marks
 * @version 
 */

import LinkedList;
import Text;

import java.io.*;
import java.util.*;
import java.lang.*;

public class HeapSimulator extends Object {

    /** Creates new HeapSimulator */
    
    public HeapSimulator() {
    }
    
    private LinkedList Heap;
    private BufferedReader fin;
    
    private MemObject FindMemObject(String vName)
    {
          Heap.BeginEnumeration();
          MemObject currentObject;
          while ((currentObject = Heap.GetNextData()) != null)
          {
               if (currentObject.ReferenceExists(vName)
               {
                    return currentObject;
               }
          }
          return null;
    }

    private void CreateNewObject(String vName)
    {
          Heap.InsertAtBack(new MemObject(vName));
    }
    private void RemoveReference(String vName)
    {
          MemObject m = FindMemObject(vName);
          if (m != null)
          {
               m.RemoveReference(vName);
          }
    }
    private void AddReference(String vName1, String vName2)
    {
          MemObject m = FindMemObject(vName2);
          if (m != null)
          {
               m.AddReference(vName1);
          }
    }
    private void PrintAllocations(PrintWriter out)
    {
        Heap.BeginEnumeration();
        MemObject m;
        String referenceName;
        while ((m = Heap.GetNextData()) != null)
        {
             out.WriteLine("Reference Count = " + m.ReferenceCount);
             m.ReferenceNames.BeginEnumeration();
             while ((referenceName = m.ReferenceNames.GetNextData()) != null)
             {
                  out.WriteLine("   Reference Name = " + referenceName);
             }
        }
    }

    private int ParseLine(String vName1, String vName2)  throws IOException
    {
        command = -1;
        String c;
        try
        {
            c = Text.readString(fin);
            if (c.equals("set"))
            {
                vName1 = Text.readString(fin);
                c = Text.readString(fin); // read an equals
                vName2 = Text.readString(fin);
                if (vName2.equals("new"))
                {
                    c = Text.readString(fin); // read in "object"
                    command = 0;
                }
                else
                {
                    command = 1;
                }
            }
            else if (c == "delete")
            {
                vName1 = Text.readString(fin);
                command = 2;
            }
            else if (c.equals("status")
            {
                command = 3;
            }
        }
        catch (EOFException e)
        {
            fin.close();
        }
        return command;
    }
    
    private void ParseInput()  throws IOException
    {
        
        int command = -1; // -1 = unrecognized command, 0 = allocate, 1 = set, 2 = deallocate
        String varName1, varName2;
        varName1 = new String();
        varName2 = new String();
        
        PrintWriter fout = Text.create("expression.out");
        try
        {
            fin = Text.open("expression.in");
            // read input file
            while(ParseLine(command, varName1, varName2))
            {
            
                switch (command)
                {
                    case 0:
 			 	RemoveReference(varName1);
                        CreateNewObject(varName1);
                        break;
                    case 1:
                        if (!AddReference(varName1,varName2))
				{
					// no object with name 'varName1' was found
				}
                        break;
                    case 2:
                        RemoveReference(varName1);
                        break;
                    case 3:
                        PrintAllocations(fout);
                    default:
                        break;
                }
            
            }
        }
        catch (FileNotFoundException f)
        {
            return;
        }
        catch (EOFException e)
        {
               
            fout.close();
        }
        
    }
    
    public static void main (String args[]) {
    }

}