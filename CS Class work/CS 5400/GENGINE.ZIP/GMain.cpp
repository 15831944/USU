#include "graphics.cpp"

int xmax;
int ymax;
const double pi = 3.141596;
int Main()
{
    // Create a full screen window.
	
    WindowClass MyWindow;
    //MyWindow.OpenWindow(0, 0, 0, 0, DOUBLE_BUFFER);
	//open window width, heigth, posx, posy, options
	MyWindow.OpenWindow(500,500, 100, 100, NORMAL_WINDOW | DOUBLE_BUFFER);
    if (!MyWindow.WindowIsOpen())
        return 255;
	xmax = MyWindow.Height;
	ymax = MyWindow.Width;

	COLORREF color;

    Vector3d Points[20];
	for (int i = 1; i < 20; i++)
		Points[i].LineTo = true;

	Points[0].x = -1;
	Points[0].y = 1;
	Points[0].z = -1;
	
	Points[0].LineTo = false;

	Points[1].x = 1;
	Points[1].y = 1;
	Points[1].z = -1;
	Points[2].x = 1;
	Points[2].y = 1;
	Points[2].z = 1;
	Points[3].x = -1;
	Points[3].y = 1;
	Points[3].z = 1;
	Points[4].x = -1;
	Points[4].y = -1;
	Points[4].z = 1;
	Points[5].x = 1;
	Points[5].y = -1;
	Points[5].z = 1;
	Points[6].x = 1;
	Points[6].y = -1;
	Points[6].z = -1;
	Points[7].x = -1;
	Points[7].y = -1;
	Points[7].z = -1;
	Points[8].x = -1;
	Points[8].y = 1;
	Points[8].z = -1;
	Points[9].x = -1;
	Points[9].y = 1;
	Points[9].z = 1;
	Points[10].x = -1;
	Points[10].y = -1;
	Points[10].z = 1;
	Points[11].x = -1;
	Points[11].y = -1;
	Points[11].z = -1;
	Points[12].x = 1;
	Points[12].y = -1;
	Points[12].z = -1;
	Points[13].x = 1;
	Points[13].y = 1;
	Points[13].z = -1;
	Points[14].x = 1;
	Points[14].y = 1;
	Points[14].z = 1;
	Points[15].x = 1;
	Points[15].y = -1;
	Points[15].z = 1;
	Points[16].LineTo = false;
	Points[16].x = 3;
	Points[16].y = 0;
	Points[16].z = 0;
	Points[17].x = -3;
	Points[17].y = 0;
	Points[17].z = 0;
	Points[18].LineTo = false;
	Points[18].x = 0;
	Points[18].y = 0;
	Points[18].z = 3;
	Points[19].x = 0;
	Points[19].y = 0;
	Points[19].z = -3;
	

	

	double theta = 0;
	double viewx;
	double viewz;
	
	while (MyWindow.WindowIsOpen())
    {
		viewx = cos(theta) * 5.0;
		viewz = sin(theta) * 5.0;
	
		Vector3d ViewPoint(viewx,2,viewz);
		Vector3d CenterPoint(0,0,0);
		MyWindow.ClearWindow();
		MyWindow.ProjectPoints(Points,20,ViewPoint,CenterPoint,3);
		MyWindow.SwapBuffers();
		
		// Wait for escape to be pressed.
        theta += pi / 64;
		if (theta >= pi * 2)
			theta = 0;
		MyWindow.CheckEscape();
    }

    return 0;
}