// EventRecordSet.cpp : implementation file
//

#include "stdafx.h"
#include "TripTracking.h"
#include "EventRecordSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEventRecordSet

IMPLEMENT_DYNAMIC(CEventRecordSet, CRecordset)

CEventRecordSet::CEventRecordSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CEventRecordSet)
	m_ItineraryID = 0;
	m_Type = 0;
	m_Name = _T("");
	m_LocationID = 0;
	m_Resources = _T("");
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CEventRecordSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=TripDB");
}

CString CEventRecordSet::GetDefaultSQL()
{
	return _T("[Event]");
}

void CEventRecordSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CEventRecordSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[ItineraryID]"), m_ItineraryID);
	RFX_Long(pFX, _T("[Type]"), m_Type);
	RFX_Text(pFX, _T("[Name]"), m_Name);
	RFX_Long(pFX, _T("[LocationID]"), m_LocationID);
	RFX_Text(pFX, _T("[Resources]"), m_Resources);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CEventRecordSet diagnostics

#ifdef _DEBUG
void CEventRecordSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CEventRecordSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
