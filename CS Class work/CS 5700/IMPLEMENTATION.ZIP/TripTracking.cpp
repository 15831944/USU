// TripTracking.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "TripTracking.h"
#include "LoginScreen.h"
#include "MainMenuDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTripTrackingApp

BEGIN_MESSAGE_MAP(CTripTrackingApp, CWinApp)
	//{{AFX_MSG_MAP(CTripTrackingApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// The one and only CTripTrackingApp object
//
CTripTrackingApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTripTrackingApp construction
//
CTripTrackingApp::CTripTrackingApp() :
	db(NULL)
{
	// At this point, we don't have any special to do during constructor
	// of the app object
}

/////////////////////////////////////////////////////////////////////////////
// CTripTrackingApp destructor
//
CTripTrackingApp::~CTripTrackingApp()
{
	if (db)
	{
		if (db->IsOpen())
			db->Close();
		delete db;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTripTrackingApp initialization

BOOL CTripTrackingApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	if (openDB())
	{
		LoginScreen dlg;
		int nResponse = dlg.DoModal();

		if (nResponse == IDOK)
		{
			MainMenuDlg mm_dlg;
			m_pMainWnd = &mm_dlg;
			mm_dlg.DoModal();
		}
		else
			AfxMessageBox("Invalid username or password.");
	}
	else
		AfxMessageBox("Can't open Trip Tracking Database.  Make sure the TripDB ODBC connection has been defined");

	return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// CTripTrackingApp::openDB

BOOL CTripTrackingApp::openDB()
{
	db = new CDatabase;
	return db->Open("TripDB");
}
