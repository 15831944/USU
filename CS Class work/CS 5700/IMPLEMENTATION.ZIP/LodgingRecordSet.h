#if !defined(AFX_LODGINGRECORDSET_H__C3D6A6C1_E659_11D5_9E3F_00A0CC55A9B1__INCLUDED_)
#define AFX_LODGINGRECORDSET_H__C3D6A6C1_E659_11D5_9E3F_00A0CC55A9B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LodgingRecordSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLodgingRecordSet recordset

class CLodgingRecordSet : public CRecordset
{
public:
	CLodgingRecordSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CLodgingRecordSet)

// Field/Param Data
	//{{AFX_FIELD(CLodgingRecordSet, CRecordset)
	long	m_ItineraryID;
	long	m_LocationID;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLodgingRecordSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LODGINGRECORDSET_H__C3D6A6C1_E659_11D5_9E3F_00A0CC55A9B1__INCLUDED_)
