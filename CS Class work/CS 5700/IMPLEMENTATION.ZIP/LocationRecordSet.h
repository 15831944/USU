#if !defined(AFX_LOCATIONRECORDSET_H__DD963563_E63D_11D5_9E3F_00A0CC41368B__INCLUDED_)
#define AFX_LOCATIONRECORDSET_H__DD963563_E63D_11D5_9E3F_00A0CC41368B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LocationRecordSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLocationRecordSet recordset

class CLocationRecordSet : public CRecordset
{
public:
	CString toString();
	static  CLocationRecordSet* getLocation(int ID);
	CLocationRecordSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CLocationRecordSet)

// Field/Param Data
	//{{AFX_FIELD(CLocationRecordSet, CRecordset)
	long	m_LocationID;
	CString	m_Name;
	CString	m_Country;
	CString	m_State;
	CString	m_City;
	CString	m_Address;
	CString	m_Room;
	CString	m_Description;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLocationRecordSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOCATIONRECORDSET_H__DD963563_E63D_11D5_9E3F_00A0CC41368B__INCLUDED_)
