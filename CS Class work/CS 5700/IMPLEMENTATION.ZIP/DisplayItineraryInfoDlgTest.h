#if !defined(AFX_DISPLAYITINERARYINFODLGTEST_H__E8418823_E63D_11D5_9E3F_00A0CC55A9B1__INCLUDED_)
#define AFX_DISPLAYITINERARYINFODLGTEST_H__E8418823_E63D_11D5_9E3F_00A0CC55A9B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DisplayItineraryInfoDlgTest.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDisplayItineraryInfoDlgTest dialog

class CDisplayItineraryInfoDlgTest : public CDialog
{
// Construction
public:
	int m_TripID;
	CDisplayItineraryInfoDlgTest(int TripID, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDisplayItineraryInfoDlgTest)
	enum { IDD = IDD_TEST_ITINERARY_INFO };
	CListCtrl	m_ItineraryList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDisplayItineraryInfoDlgTest)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDisplayItineraryInfoDlgTest)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DISPLAYITINERARYINFODLGTEST_H__E8418823_E63D_11D5_9E3F_00A0CC55A9B1__INCLUDED_)
