// CreateTripDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TripTracking.h"
#include "CreateTripDlg.h"
#include "SelectDate.h"
#include "FindLocationDlg.h"
#include "LocationRecordSet.h"
#include "TripRecordSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const CString DATE_FORMAT = "%m/%d/%y %H:%M:%S";
/////////////////////////////////////////////////////////////////////////////
// CCreateTripDlg dialog


CCreateTripDlg::CCreateTripDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCreateTripDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCreateTripDlg)
	m_DepartureDate = _T("");
	m_Location = _T("");
	m_ReturnDate = _T("");
	m_Synopsis = _T("");
	m_Name = _T("");
	//}}AFX_DATA_INIT
	m_LocationID = -1;
}


void CCreateTripDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCreateTripDlg)
	DDX_Text(pDX, IDC_DEPARTURE_DATE, m_DepartureDate);
	DDX_Text(pDX, IDC_LOCATION, m_Location);
	DDX_Text(pDX, IDC_RETURN_DATE, m_ReturnDate);
	DDX_Text(pDX, IDC_SYNOPSIS, m_Synopsis);
	DDX_Text(pDX, IDC_TRIP_NAME, m_Name);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCreateTripDlg, CDialog)
	//{{AFX_MSG_MAP(CCreateTripDlg)
	ON_BN_CLICKED(IDC_SELECT_DEPARTURE, OnSelectDeparture)
	ON_BN_CLICKED(IDC_SELECT_LOCATION, OnSelectLocation)
	ON_BN_CLICKED(IDC_SELECT_RETURN, OnSelectReturn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCreateTripDlg message handlers

void CCreateTripDlg::OnSelectDeparture() 
{
	// TODO: Add your control notification handler code here
	CSelectDate cDlg;
	if (cDlg.DoModal() == IDOK)
	{
		UpdateData();
		m_DepartureDate = cDlg.m_DateTimeSelected.Format(DATE_FORMAT);
		m_DepTime = cDlg.m_DateTimeSelected;

		UpdateData(FALSE);
	}
}

void CCreateTripDlg::OnSelectLocation() 
{
	// TODO: Add your control notification handler code here
	CFindLocationDlg cDlg;
	if (cDlg.DoModal() == IDOK)
	{
		UpdateData();
		m_LocationID = cDlg.m_SelectedLocationID;
		CLocationRecordSet * ptrLocationRecord = CLocationRecordSet::getLocation(m_LocationID);
		m_Location = ptrLocationRecord->m_Name;
		UpdateData(FALSE);
	}
}

void CCreateTripDlg::OnSelectReturn() 
{
	// TODO: Add your control notification handler code here
	CSelectDate cDlg;
	if (cDlg.DoModal() == IDOK)
	{
		UpdateData();
		m_ReturnDate = cDlg.m_DateTimeSelected.Format(DATE_FORMAT);
		m_RetTime = cDlg.m_DateTimeSelected;
		UpdateData(FALSE);
	}
}

void CCreateTripDlg::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	if (m_Name.IsEmpty())
	{
		MessageBox("You must enter a name for this trip.","Input Error",MB_ICONINFORMATION);
		return;
	}
	else if( m_Location.IsEmpty())
	{
		MessageBox("You must select a location for this trip.","Input Error",MB_ICONINFORMATION);
		return;
	}
	else if( m_DepartureDate.IsEmpty())
	{
		MessageBox("You must select a departure date for this trip.","Input Error",MB_ICONINFORMATION);
		return;
	}
	else if( m_ReturnDate.IsEmpty())
	{
		MessageBox("You must select a return date for this trip.","Input Error",MB_ICONINFORMATION);
		return;
	}

	//add a new location
	CTripTrackingApp* app = (CTripTrackingApp*) AfxGetApp();
	CDatabase* db = app->getDB();
	CTripRecordSet trip(db);
	trip.Open();
	if(trip.CanAppend())
	{
		trip.AddNew();
		trip.m_departure_date = m_DepTime;;
		trip.m_return_date = m_RetTime;
		trip.m_name = m_Name;
		trip.m_locationID = m_LocationID;
		trip.Update();
		
	}
	else
	{
		MessageBox("Unable to write to table.");
	}

	CDialog::OnOK();
}
