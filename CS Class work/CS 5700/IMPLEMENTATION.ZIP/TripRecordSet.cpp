// TripRecordSet.cpp : implementation file
//

#include "stdafx.h"
#include "TripTracking.h"
#include "TripRecordSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTripRecordSet

IMPLEMENT_DYNAMIC(CTripRecordSet, CRecordset)

CTripRecordSet::CTripRecordSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTripRecordSet)
	m_id = 0;
	m_trip_coordinator_id = 0;
	m_name = _T("");
	m_lessons_learned = _T("");
	m_impact_description = _T("");
	m_short_synopsis = _T("");
	m_itinerary_approved = FALSE;
	m_locationID = 0;
	m_nFields = 10;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CTripRecordSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=TripDB");
}

CString CTripRecordSet::GetDefaultSQL()
{
	return _T("[Trip]");
}

void CTripRecordSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTripRecordSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[id]"), m_id);
	RFX_Long(pFX, _T("[trip_coordinator_id]"), m_trip_coordinator_id);
	RFX_Text(pFX, _T("[name]"), m_name);
	RFX_Date(pFX, _T("[departure_date]"), m_departure_date);
	RFX_Date(pFX, _T("[return_date]"), m_return_date);
	RFX_Text(pFX, _T("[lessons_learned]"), m_lessons_learned);
	RFX_Text(pFX, _T("[impact_description]"), m_impact_description);
	RFX_Text(pFX, _T("[short_synopsis]"), m_short_synopsis);
	RFX_Bool(pFX, _T("[itinerary_approved]"), m_itinerary_approved);
	RFX_Long(pFX, _T("[locationid]"), m_locationID);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CTripRecordSet diagnostics

#ifdef _DEBUG
void CTripRecordSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CTripRecordSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
