#if !defined(AFX_EVENTRECORDSET_H__E8418830_E63D_11D5_9E3F_00A0CC55A9B1__INCLUDED_)
#define AFX_EVENTRECORDSET_H__E8418830_E63D_11D5_9E3F_00A0CC55A9B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EventRecordSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEventRecordSet recordset

class CEventRecordSet : public CRecordset
{
public:
	CEventRecordSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CEventRecordSet)

// Field/Param Data
	//{{AFX_FIELD(CEventRecordSet, CRecordset)
	long	m_ItineraryID;
	long	m_Type;
	CString	m_Name;
	long	m_LocationID;
	CString	m_Resources;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEventRecordSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EVENTRECORDSET_H__E8418830_E63D_11D5_9E3F_00A0CC55A9B1__INCLUDED_)
