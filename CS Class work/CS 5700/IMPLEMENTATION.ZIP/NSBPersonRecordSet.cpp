// NSBPersonRecordSet.cpp : implementation file
//

#include "stdafx.h"
#include "TripTracking.h"
#include "NSBPersonRecordSet.h"

//#ifdef _DEBUG
//#define new DEBUG_NEW
//#undef THIS_FILE
//static char THIS_FILE[] = __FILE__;
//#endif

/////////////////////////////////////////////////////////////////////////////
// CNSBPersonRecordSet

IMPLEMENT_DYNAMIC(CNSBPersonRecordSet, CRecordset)

CNSBPersonRecordSet::CNSBPersonRecordSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CNSBPersonRecordSet)
	m_id = 0;
	m_can_travel = FALSE;
	m_can_coordinate = FALSE;
	m_role = _T("");
	m_username = _T("");
	m_password = _T("");
	m_nFields = 6;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CNSBPersonRecordSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=TripDB");
}

CString CNSBPersonRecordSet::GetDefaultSQL()
{
	return _T("[NSBPerson]");
}

void CNSBPersonRecordSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CNSBPersonRecordSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[id]"), m_id);
	RFX_Bool(pFX, _T("[can_travel]"), m_can_travel);
	RFX_Bool(pFX, _T("[can_coordinate]"), m_can_coordinate);
	RFX_Text(pFX, _T("[role]"), m_role);
	RFX_Text(pFX, _T("[username]"), m_username);
	RFX_Text(pFX, _T("[password]"), m_password);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CNSBPersonRecordSet diagnostics

#ifdef _DEBUG
void CNSBPersonRecordSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CNSBPersonRecordSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
