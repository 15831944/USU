// MainMenuDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TripTracking.h"
#include "MainMenuDlg.h"
#include "TripRecordSet.h"
#include "DisplayItineraryInfoDlgTest.h"
#include "CreateTripDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// MainMenuDlg dialog


MainMenuDlg::MainMenuDlg(CWnd* pParent /*=NULL*/)
	: CDialog(MainMenuDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(MainMenuDlg)
	//}}AFX_DATA_INIT
}


void MainMenuDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(MainMenuDlg)
	DDX_Control(pDX, IDC_TRIP_LIST, m_trip_list);
	//}}AFX_DATA_MAP
}

BOOL MainMenuDlg::OnInitDialog(void)
{
	const CString DATE_FORMAT = "%m/%d/%y";

	CDialog::OnInitDialog();

	// Get a reference to the database
	CTripTrackingApp* app = (CTripTrackingApp*) AfxGetApp();
	CDatabase* db = app->getDB();

	CTripRecordSet trips(db);
	if (trips.Open())
	{
		m_trip_list.ResetContent();
		if (!trips.IsBOF())				// The recordset is not empty
		{
			while (!trips.IsEOF())		// Loop through all the records
			{
				CString trip =	trips.m_name + ", " +
								trips.m_departure_date.Format(DATE_FORMAT) +
								" to " +
								trips.m_return_date.Format(DATE_FORMAT);
				m_trip_list.SetItemData(m_trip_list.AddString(trip), trips.m_id);
				trips.MoveNext( );		// Move to the next record
			}
		}
	}

	return TRUE;
}


BEGIN_MESSAGE_MAP(MainMenuDlg, CDialog)
	//{{AFX_MSG_MAP(MainMenuDlg)
	ON_BN_CLICKED(IDC_MAINT_STAFF_INFO, OnMaintStaffInfo)
	ON_BN_CLICKED(IDC_GET_IT_INFO, OnGetItInfo)
	ON_BN_CLICKED(IDC_NEW_TRIP, OnNewTrip)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// MainMenuDlg message handlers

void MainMenuDlg::OnMaintStaffInfo() 
{
	// TODO: Add your control notification handler code here
	
}

void MainMenuDlg::OnGetItInfo() 
{
	// TODO: Add your control notification handler code here
	int sel = m_trip_list.GetCurSel();
	if (sel != LB_ERR)
	{
		CDisplayItineraryInfoDlgTest c(m_trip_list.GetItemData(sel));
		c.DoModal();
	}
}

void MainMenuDlg::OnNewTrip() 
{
	// TODO: Add your control notification handler code here
	CCreateTripDlg cDlg;
	cDlg.DoModal();
}
