#if !defined(AFX_SELECTDATE_H__C3D6A6C5_E659_11D5_9E3F_00A0CC55A9B1__INCLUDED_)
#define AFX_SELECTDATE_H__C3D6A6C5_E659_11D5_9E3F_00A0CC55A9B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SelectDate.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSelectDate dialog

class CSelectDate : public CDialog
{
// Construction
public:
	CSelectDate(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSelectDate)
	enum { IDD = IDD_SELECT_DATE };
	CTime	m_Time;
	CTime	m_Date;
	//}}AFX_DATA

	CTime m_DateTimeSelected;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSelectDate)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSelectDate)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SELECTDATE_H__C3D6A6C5_E659_11D5_9E3F_00A0CC55A9B1__INCLUDED_)
