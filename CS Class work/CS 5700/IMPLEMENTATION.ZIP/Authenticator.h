// Authenticator.h: interface for the Authenticator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AUTHENTICATOR_H__DB38992A_E5F7_11D5_B509_000086204AC6__INCLUDED_)
#define AFX_AUTHENTICATOR_H__DB38992A_E5F7_11D5_B509_000086204AC6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Authenticator  
{
public:
	Authenticator(void) {};

	// Username and Password authentication
	BOOL authenticate(const CString& username, const CString& password);
};

#endif // !defined(AFX_AUTHENTICATOR_H__DB38992A_E5F7_11D5_B509_000086204AC6__INCLUDED_)
