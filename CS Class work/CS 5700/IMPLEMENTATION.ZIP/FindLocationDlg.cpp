// FindLocationDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TripTracking.h"
#include "FindLocationDlg.h"
#include "LocationRecordSet.h"
#include "EditLocationDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFindLocationDlg dialog


CFindLocationDlg::CFindLocationDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFindLocationDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFindLocationDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CFindLocationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFindLocationDlg)
	DDX_Control(pDX, IDC_LOCATION_LIST, m_LocationList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFindLocationDlg, CDialog)
	//{{AFX_MSG_MAP(CFindLocationDlg)
	ON_BN_CLICKED(IDC_NEW_LOCATION, OnNewLocation)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFindLocationDlg message handlers

BOOL CFindLocationDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	RefreshList();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFindLocationDlg::OnOK() 
{
	// TODO: Add extra validation here
	int curSel = m_LocationList.GetCurSel();
	if (curSel == LB_ERR)
	{
		MessageBox("You must first select a location.","Error",MB_ICONINFORMATION);
		return;
	}
	else
	{
		m_SelectedLocationID = m_LocationList.GetItemData(curSel);
	}

	CDialog::OnOK();
}

void CFindLocationDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	m_SelectedLocationID = -1;
	CDialog::OnCancel();
}

void CFindLocationDlg::OnNewLocation() 
{
	// TODO: Add your control notification handler code here
	CEditLocationDlg cDlg;
	cDlg.DoModal();
	RefreshList();
}

void CFindLocationDlg::RefreshList()
{
	// create a CLocationRecordSet object, go through all of the locations and add
	// each to the list box...
	CTripTrackingApp* app = (CTripTrackingApp*) AfxGetApp();
	CDatabase* db = app->getDB();

	CLocationRecordSet locations(db);
	if (locations.Open())
	{
		m_LocationList.ResetContent();
		if (!locations.IsBOF())				// The recordset is not empty
		{
			while (!locations.IsEOF())		// Loop through all the records
			{
				CString lname =	locations.m_Name;
				m_LocationList.SetItemData(m_LocationList.AddString(lname), locations.m_LocationID);
				locations.MoveNext( );		// Move to the next record
			}
		}
	}

}
