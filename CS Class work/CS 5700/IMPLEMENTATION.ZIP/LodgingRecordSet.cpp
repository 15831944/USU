// LodgingRecordSet.cpp : implementation file
//

#include "stdafx.h"
#include "TripTracking.h"
#include "LodgingRecordSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLodgingRecordSet

IMPLEMENT_DYNAMIC(CLodgingRecordSet, CRecordset)

CLodgingRecordSet::CLodgingRecordSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CLodgingRecordSet)
	m_ItineraryID = 0;
	m_LocationID = 0;
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CLodgingRecordSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=TripDB");
}

CString CLodgingRecordSet::GetDefaultSQL()
{
	return _T("[Lodging]");
}

void CLodgingRecordSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CLodgingRecordSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[ItineraryID]"), m_ItineraryID);
	RFX_Long(pFX, _T("[LocationID]"), m_LocationID);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CLodgingRecordSet diagnostics

#ifdef _DEBUG
void CLodgingRecordSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CLodgingRecordSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
