// LocationRecordSet.cpp : implementation file
//

#include "stdafx.h"
#include "TripTracking.h"
#include "LocationRecordSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLocationRecordSet

IMPLEMENT_DYNAMIC(CLocationRecordSet, CRecordset)

CLocationRecordSet::CLocationRecordSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CLocationRecordSet)
	m_LocationID = 0;
	m_Name = _T("");
	m_Country = _T("");
	m_State = _T("");
	m_City = _T("");
	m_Address = _T("");
	m_Room = _T("");
	m_Description = _T("");
	m_nFields = 8;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CLocationRecordSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=TripDB");
}

CString CLocationRecordSet::GetDefaultSQL()
{
	return _T("[Location]");
}

void CLocationRecordSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CLocationRecordSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[LocationID]"), m_LocationID);
	RFX_Text(pFX, _T("[Name]"), m_Name);
	RFX_Text(pFX, _T("[Country]"), m_Country);
	RFX_Text(pFX, _T("[State]"), m_State);
	RFX_Text(pFX, _T("[City]"), m_City);
	RFX_Text(pFX, _T("[Address]"), m_Address);
	RFX_Text(pFX, _T("[Room]"), m_Room);
	RFX_Text(pFX, _T("[Description]"), m_Description);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CLocationRecordSet diagnostics

#ifdef _DEBUG
void CLocationRecordSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CLocationRecordSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG

CLocationRecordSet* CLocationRecordSet::getLocation(int ID)
{

	CTripTrackingApp* app = (CTripTrackingApp*) AfxGetApp();
	CDatabase* db = app->getDB();

	CString sqlSelect;
	sqlSelect.Format("SELECT * FROM Location WHERE LocationID= %i", ID);

	// Look for the specified username and password
	CLocationRecordSet *location = new CLocationRecordSet(db);

	if (location->Open(CRecordset::snapshot, sqlSelect))
	{
		// If there is at least one record, then the username and password
		// was found and there the pair is valid
		if (location->GetRecordCount()>0)
			return location;
	}

	return NULL;
}

//Open must already be called
CString CLocationRecordSet::toString()
{
	CString result;
	result = m_Name;
	result += "  ";
	result += m_Room;
	result += "  ";
	result += m_Address;
	result += "  ";
	result += m_City;
	result += "  ";
	result += m_State;
	result += "  ";
	result += m_Country;
	result += "  ";
	result += m_Description;
	
	return result;
}
