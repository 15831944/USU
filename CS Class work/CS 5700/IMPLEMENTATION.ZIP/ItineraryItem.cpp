// ItineraryItem.cpp : implementation file
//

#include "stdafx.h"
#include "TripTracking.h"
#include "ItineraryItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CItineraryItem

IMPLEMENT_DYNAMIC(CItineraryItem, CRecordset)

CItineraryItem::CItineraryItem(int TripID, CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CItineraryItem)
	m_ItineraryID = 0;
	m_TripID = TripID;
	m_Type = 0;
	m_Cost = _T("");
	m_Description = _T("");
	m_nFields = 7;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CItineraryItem::GetDefaultConnect()
{
	return _T("ODBC;DSN=TripDB");
}

CString CItineraryItem::GetDefaultSQL()
{
	CString sqlStatement;
	sqlStatement.Format("SELECT * FROM ItineraryItem WHERE TripID = %i", m_TripID);
	return _T(sqlStatement);
}

void CItineraryItem::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CItineraryItem)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[ItineraryID]"), m_ItineraryID);
	RFX_Long(pFX, _T("[TripID]"), m_TripID);
	RFX_Long(pFX, _T("[Type]"), m_Type);
	RFX_Text(pFX, _T("[Cost]"), m_Cost);
	RFX_Text(pFX, _T("[Description]"), m_Description);
	RFX_Date(pFX, _T("[StartTime]"), m_StartTime);
	RFX_Date(pFX, _T("[EndTime]"), m_EndTime);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CItineraryItem diagnostics

#ifdef _DEBUG
void CItineraryItem::AssertValid() const
{
	CRecordset::AssertValid();
}

void CItineraryItem::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
