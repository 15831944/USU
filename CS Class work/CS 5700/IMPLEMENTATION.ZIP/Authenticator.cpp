// Authenticator.cpp: implementation of the Authenticator class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TripTracking.h"
#include "Authenticator.h"
#include "NSBPersonRecordSet.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Authenticator::Authenticate(username, password)
//
BOOL Authenticator::authenticate(const CString& username, const CString& password)
{
	BOOL result = FALSE;

	// Get a reference to the database
	CTripTrackingApp* app = (CTripTrackingApp*) AfxGetApp();
	CDatabase* db = app->getDB();

	CString sqlSelect = "SELECT * FROM NSBPerson WHERE username='" +
						username + "' AND password='" + password + "'";

	// Look for the specified username and password
	CNSBPersonRecordSet users(db);

	if (users.Open(CRecordset::snapshot, sqlSelect))
	{
		// If there is at least one record, then the username and password
		// was found and there the pair is valid
		if (users.GetRecordCount()>0)
			result = TRUE;
	}

	return result;
}
