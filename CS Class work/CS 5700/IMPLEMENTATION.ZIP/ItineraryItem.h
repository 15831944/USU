#if !defined(AFX_ITINERARYITEM_H__E8418821_E63D_11D5_9E3F_00A0CC55A9B1__INCLUDED_)
#define AFX_ITINERARYITEM_H__E8418821_E63D_11D5_9E3F_00A0CC55A9B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ItineraryItem.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CItineraryItem recordset

class CItineraryItem : public CRecordset
{
public:
	CItineraryItem(int TripID, CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CItineraryItem)

// Field/Param Data
	//{{AFX_FIELD(CItineraryItem, CRecordset)
	long	m_ItineraryID;
	long	m_TripID;
	long	m_Type;
	CString	m_Cost;
	CString	m_Description;
	CTime	m_StartTime;
	CTime	m_EndTime;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CItineraryItem)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ITINERARYITEM_H__E8418821_E63D_11D5_9E3F_00A0CC55A9B1__INCLUDED_)
