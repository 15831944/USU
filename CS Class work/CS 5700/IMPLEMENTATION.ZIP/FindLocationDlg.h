#if !defined(AFX_FINDLOCATIONDLG_H__C3D6A6C4_E659_11D5_9E3F_00A0CC55A9B1__INCLUDED_)
#define AFX_FINDLOCATIONDLG_H__C3D6A6C4_E659_11D5_9E3F_00A0CC55A9B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FindLocationDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFindLocationDlg dialog

class CFindLocationDlg : public CDialog
{
// Construction
public:
	void RefreshList();
	int m_SelectedLocationID;
	CFindLocationDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFindLocationDlg)
	enum { IDD = IDD_FIND_LOCATION };
	CListBox	m_LocationList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFindLocationDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFindLocationDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnNewLocation();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FINDLOCATIONDLG_H__C3D6A6C4_E659_11D5_9E3F_00A0CC55A9B1__INCLUDED_)
