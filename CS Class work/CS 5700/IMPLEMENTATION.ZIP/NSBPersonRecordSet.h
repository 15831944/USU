#if !defined(AFX_NSBPERSONRECORDSET_H__6116DE92_E5F3_11D5_B509_000086204AC6__INCLUDED_)
#define AFX_NSBPERSONRECORDSET_H__6116DE92_E5F3_11D5_B509_000086204AC6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NSBPersonRecordSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNSBPersonRecordSet recordset

class CNSBPersonRecordSet : public CRecordset
{
public:
	CNSBPersonRecordSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CNSBPersonRecordSet)

// Field/Param Data
	//{{AFX_FIELD(CNSBPersonRecordSet, CRecordset)
	long	m_id;
	BOOL	m_can_travel;
	BOOL	m_can_coordinate;
	CString	m_role;
	CString	m_username;
	CString	m_password;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNSBPersonRecordSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NSBPERSONRECORDSET_H__6116DE92_E5F3_11D5_B509_000086204AC6__INCLUDED_)
