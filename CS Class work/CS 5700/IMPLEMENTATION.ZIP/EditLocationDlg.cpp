// EditLocationDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TripTracking.h"
#include "EditLocationDlg.h"
#include "FindLocationDlg.h"
#include "LocationRecordSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditLocationDlg dialog


CEditLocationDlg::CEditLocationDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEditLocationDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEditLocationDlg)
	m_Address = _T("");
	m_City = _T("");
	m_Country = _T("");
	m_Description = _T("");
	m_Name = _T("");
	m_Room = _T("");
	m_State = _T("");
	//}}AFX_DATA_INIT
}


void CEditLocationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditLocationDlg)
	DDX_Text(pDX, IDC_ADDRESS, m_Address);
	DDX_Text(pDX, IDC_CITY, m_City);
	DDX_Text(pDX, IDC_COUNTRY, m_Country);
	DDX_Text(pDX, IDC_DESCRIPTION, m_Description);
	DDX_Text(pDX, IDC_NAME, m_Name);
	DDX_Text(pDX, IDC_ROOM, m_Room);
	DDX_Text(pDX, IDC_STATE, m_State);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEditLocationDlg, CDialog)
	//{{AFX_MSG_MAP(CEditLocationDlg)
	ON_BN_CLICKED(IDC_FIND_LOCATION, OnFindLocation)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditLocationDlg message handlers

void CEditLocationDlg::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	// all the data is now stored in all the member fields...
	
	//add a new location
	CTripTrackingApp* app = (CTripTrackingApp*) AfxGetApp();
	CDatabase* db = app->getDB();
	CLocationRecordSet location(db);
	location.Open();
	if(location.CanAppend())
	{
		location.AddNew();
		//how do you specify the ID?
		//location.m_LocationID
		location.m_Name = m_Name;
		location.m_Country = m_Country;
		location.m_State = m_State;
		location.m_City = m_City;
		location.m_Address = m_Address;
		location.m_Room = m_Room;
		location.m_Description = m_Description;
		location.Update(); 
	}
	else
	{
		MessageBox("Unable to write to table.");
	}

	CDialog::OnOK();
}

void CEditLocationDlg::OnFindLocation() 
{
	// TODO: Add your control notification handler code here
	CFindLocationDlg cDlg;
	cDlg.DoModal();
	if (cDlg.m_SelectedLocationID != -1)
	{
		// use the selected ID and the Location class to get a location
		// object, then use the data from that object to populate the fields
		// in this dialog...
	}
}
