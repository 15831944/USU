// SelectDate.cpp : implementation file
//

#include "stdafx.h"
#include "TripTracking.h"
#include "SelectDate.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSelectDate dialog


CSelectDate::CSelectDate(CWnd* pParent /*=NULL*/)
	: CDialog(CSelectDate::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSelectDate)
	m_Time = CTime::GetCurrentTime();
	m_Date = CTime::GetCurrentTime();
	//}}AFX_DATA_INIT
}


void CSelectDate::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSelectDate)
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER, m_Time);
	DDX_DateTimeCtrl(pDX, IDC_DATE, m_Date);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSelectDate, CDialog)
	//{{AFX_MSG_MAP(CSelectDate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSelectDate message handlers

void CSelectDate::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	//CString date;
	//date = m_Date.Format("%m/%d/%y");
	//CString datetime = m_Date.Format("%H:%M:%S");
	//CString time;
	//time = m_Time.Format("%H:%M:%S");

	
	//MessageBox(CString("date = ") + date);
	m_DateTimeSelected = CTime(m_Date.GetYear(),m_Date.GetMonth(),m_Date.GetDay(),m_Time.GetHour(),m_Time.GetMinute(),m_Time.GetSecond());
	CDialog::OnOK();
}
