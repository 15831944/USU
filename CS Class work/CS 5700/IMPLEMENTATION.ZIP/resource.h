//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TripTracking.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TRIPTRACKING_DIALOG         102
#define IDD_LOGINSCREEN_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDD_MAIN_MENU                   129
#define IDD_TEST_ITINERARY_INFO         130
#define IDD_CREATE_TRIP                 131
#define IDD_LOCATION                    132
#define IDD_FIND_LOCATION               133
#define IDD_SELECT_DATE                 134
#define IDC_USERNAME                    1000
#define IDC_PASSWORD                    1001
#define IDC_NEW_TRIP                    1001
#define IDC_MAINT_STAFF_INFO            1003
#define IDC_RECORD_TRIP_INFO            1004
#define IDC_TRIP_LIST                   1005
#define IDC_ITINERARY_LIST              1006
#define IDC_GET_IT_INFO                 1007
#define IDC_TRIP_NAME                   1008
#define IDC_DEPARTURE_DATE              1009
#define IDC_RETURN_DATE                 1010
#define IDC_LOCATION                    1011
#define IDC_SYNOPSIS                    1012
#define IDC_SELECT_DEPARTURE            1013
#define IDC_SELECT_RETURN               1014
#define IDC_SELECT_LOCATION             1015
#define IDC_NAME                        1016
#define IDC_COUNTRY                     1017
#define IDC_LOCATION_LIST               1017
#define IDC_STATE                       1018
#define IDC_CITY                        1019
#define IDC_ADDRESS                     1020
#define IDC_ROOM                        1021
#define IDC_DESCRIPTION                 1022
#define IDC_FIND_LOCATION               1023
#define IDC_NEW_LOCATION                1024
#define IDC_DATETIMEPICKER              1025
#define IDC_DATE                        1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
