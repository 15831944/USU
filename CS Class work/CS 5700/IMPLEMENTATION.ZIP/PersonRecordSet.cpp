// PersonRecordSet.cpp : implementation file
//

#include "stdafx.h"
#include "TripTracking.h"
#include "PersonRecordSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPersonRecordSet

IMPLEMENT_DYNAMIC(CPersonRecordSet, CRecordset)

CPersonRecordSet::CPersonRecordSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CPersonRecordSet)
	m_id = 0;
	m_name = _T("");
	m_agency_or_company = _T("");
	m_title = _T("");
	m_is_nsb_person = FALSE;
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CPersonRecordSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=TripDB");
}

CString CPersonRecordSet::GetDefaultSQL()
{
	return _T("[Person]");
}

void CPersonRecordSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CPersonRecordSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[id]"), m_id);
	RFX_Text(pFX, _T("[name]"), m_name);
	RFX_Text(pFX, _T("[agency_or_company]"), m_agency_or_company);
	RFX_Text(pFX, _T("[title]"), m_title);
	RFX_Bool(pFX, _T("[is_nsb_person]"), m_is_nsb_person);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CPersonRecordSet diagnostics

#ifdef _DEBUG
void CPersonRecordSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CPersonRecordSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
