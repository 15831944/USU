#if !defined(AFX_PERSONRECORDSET_H__6116DE90_E5F3_11D5_B509_000086204AC6__INCLUDED_)
#define AFX_PERSONRECORDSET_H__6116DE90_E5F3_11D5_B509_000086204AC6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PersonRecordSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPersonRecordSet recordset

class CPersonRecordSet : public CRecordset
{
public:
	CPersonRecordSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CPersonRecordSet)

// Field/Param Data
	//{{AFX_FIELD(CPersonRecordSet, CRecordset)
	long	m_id;
	CString	m_name;
	CString	m_agency_or_company;
	CString	m_title;
	BOOL	m_is_nsb_person;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPersonRecordSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PERSONRECORDSET_H__6116DE90_E5F3_11D5_B509_000086204AC6__INCLUDED_)
