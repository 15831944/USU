#include "LocationRecordSet.h"




//edit a location
CLocationRecordSet* location = CLocationRecordSet::getLocation(ID);//ID for the Location to edit

location->Edit();

location->m_Name = m_Name;
location->m_Country = m_Country;
location->m_State = m_State;
location->m_City = m_City;
location->m_Address = m_Address;
location->m_Room = m_Room;
location->m_Description = m_Description;

location->Update(); 


