// DisplayItineraryInfoDlgTest.cpp : implementation file
//

#include "stdafx.h"
#include "TripTracking.h"
#include "DisplayItineraryInfoDlgTest.h"
#include "ItineraryItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const CString DATE_FORMAT = "%m/%d/%y";

/////////////////////////////////////////////////////////////////////////////
// CDisplayItineraryInfoDlgTest dialog


CDisplayItineraryInfoDlgTest::CDisplayItineraryInfoDlgTest(int TripID, CWnd* pParent /*=NULL*/)
	: CDialog(CDisplayItineraryInfoDlgTest::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDisplayItineraryInfoDlgTest)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_TripID = TripID;
}


void CDisplayItineraryInfoDlgTest::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDisplayItineraryInfoDlgTest)
	DDX_Control(pDX, IDC_ITINERARY_LIST, m_ItineraryList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDisplayItineraryInfoDlgTest, CDialog)
	//{{AFX_MSG_MAP(CDisplayItineraryInfoDlgTest)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDisplayItineraryInfoDlgTest message handlers

BOOL CDisplayItineraryInfoDlgTest::OnInitDialog() 
{
	CDialog::OnInitDialog();
		// TODO: Add extra initialization here
	// Get a reference to the database
	CTripTrackingApp* app = (CTripTrackingApp*) AfxGetApp();
	CDatabase* db = app->getDB();
	m_ItineraryList.InsertColumn(0,"Start Time");
	m_ItineraryList.InsertColumn(1,"End Time");
	m_ItineraryList.InsertColumn(2,"Type");
	m_ItineraryList.InsertColumn(3,"Cost");
	m_ItineraryList.InsertColumn(4,"Description");

	CItineraryItem items(m_TripID, db);
	if (items.Open())
	{
		m_ItineraryList.DeleteAllItems();
		if (!items.IsBOF())				// The recordset is not empty
		{
			int newRow;
			CString text;
			while (!items.IsEOF())		// Loop through all the records
			{
				text = items.m_StartTime.Format(DATE_FORMAT);
				newRow = m_ItineraryList.InsertItem(0,text);
				
				text = items.m_EndTime.Format(DATE_FORMAT);
				m_ItineraryList.SetItemText(newRow,1,text);
				
				text.Format("%i",items.m_Type);
				m_ItineraryList.SetItemText(newRow,2,text);

				m_ItineraryList.SetItemText(newRow,3,items.m_Cost);

				m_ItineraryList.SetItemText(newRow,4,items.m_Description);

				items.MoveNext( );		// Move to the next record
			}
		}
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
