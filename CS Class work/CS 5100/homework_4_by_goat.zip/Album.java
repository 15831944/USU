/*
 * Album.java
 *
 * Created on February 25, 2002, 10:10 PM
 */

//package Album;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.border.BevelBorder;
import ExampleFileFilter;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.beans.*;
import java.awt.MediaTracker;
import javax.swing.Timer;
/**
 *
 * @author  Mark Salisbury
 */
public class Album extends javax.swing.JPanel {

    class AboutDialog extends JDialog {
        private JOptionPane optionPane;

        public AboutDialog() {
            super(frame, true);

            setTitle("About Photo Album");
            setSize(300,200);
            String m1, m2, m3;
               
            m1 = new String("Photo Album Program");
            m2 = new String("Written for CS 5100 2/6/2002");
            m3 = new String("by Mark Salisbury");
                                  
            Object[] array = {m1,m2,m3};        
            final String btnString1 = "OK";
            
            Object[] options = {btnString1};

            optionPane = new JOptionPane(array, 
                                        JOptionPane.INFORMATION_MESSAGE,
                                        JOptionPane.OK_OPTION ,
                                        null,
                                        options,
                                        options[0]);
            setContentPane(optionPane);
            setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
            addWindowListener(new WindowAdapter() {
                    public void windowClosing(WindowEvent we) {
                    /*
                     * Instead of directly closing the window,
                     * we're going to change the JOptionPane's
                     * value property.
                     */
                        optionPane.setValue(new Integer(
                                            JOptionPane.CLOSED_OPTION));
                }
            });
                  
            optionPane.addPropertyChangeListener(new PropertyChangeListener() {
                public void propertyChange(PropertyChangeEvent e) 
                {
                    setVisible(false);
                }}
            );
        }
    }
    
    class AutoWindow extends JWindow
    {
        public boolean CanReceiveCloseEvent;
        private Timer myTimer;
        public Dimension screenSize;
        public JLabel pictureLabel;
        
        private void DoCloseCheck()
        {
            if (CanReceiveCloseEvent)
            {
               pAlbum.setViewingMode(1);
               myTimer.stop();
            }
        }
        
        class AutoMouseListener implements MouseListener
        {
            public void mouseClicked(MouseEvent m)
            {
                DoCloseCheck();
            }
            public void mousePressed(MouseEvent m)
            {
                DoCloseCheck();
            }
            public void mouseReleased(MouseEvent m)
            {
                DoCloseCheck();
            }
            public void mouseEntered(MouseEvent m)
            {
                DoCloseCheck();
            }
            public void mouseExited(MouseEvent m)
            {
                DoCloseCheck();
            }
        }
        
        class AutoMouseMotionListener implements MouseMotionListener
        {
            public void mouseDragged(MouseEvent m)
            {
                DoCloseCheck();
            }
            public void mouseMoved(MouseEvent m)
            {
                DoCloseCheck();
            }
        }
        
        class AutoKeyListener implements KeyListener
        {
        
            public void keyPressed(KeyEvent e)
            {
                DoCloseCheck();
            }
        
            public void keyReleased(java.awt.event.KeyEvent keyEvent) 
            {
                DoCloseCheck();
            }
        
            public void keyTyped(java.awt.event.KeyEvent keyEvent) 
            {
                DoCloseCheck();
            }
            
        }
        
        public AutoWindow(JFrame parent)
        {   
            super(parent);
            CanReceiveCloseEvent = false;
            screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            JPanel background = new JPanel();
            pictureLabel = new JLabel();
            
            background.add(pictureLabel);
            background.setLayout(null);
            background.setBackground(new Color(0,0,0));
            background.setOpaque(true);
            background.setSize(screenSize);
            this.getContentPane().add(background);
            this.getContentPane().setBackground(new Color(0,0,0));
            this.getContentPane().setLayout(null);
            this.getContentPane().setSize(screenSize);
            this.pack();
            this.setVisible(true);
            this.requestFocus();
            this.setSize(screenSize);
            this.addMouseListener(new AutoMouseListener());
            this.addMouseMotionListener(new AutoMouseMotionListener());
            this.addKeyListener(new AutoKeyListener());
            System.out.println("AutoWindow constructor finished. ScreenSize="+screenSize.getWidth()+","+screenSize.getHeight());
            
            myTimer = new Timer(5000, new FullScreenListener());
            myTimer.setInitialDelay(300);
            myTimer.setRepeats(true);
            myTimer.start();
            ///super(f);
            //JLabel l = new JLabel(new ImageIcon(filename));
            //getContentPane().add(l, BorderLayout.CENTER);
            //pack();
        
            //Dimension labelSize = l.getPreferredSize();
            //setLocation(screenSize.width/2 - (labelSize.width/2),
            //        screenSize.height/2 - (labelSize.height/2));
            //setVisible(true);
            //screenSize = null;
            //labelSize = null;
            
        }
    }
    
    class AlbumFiles extends JFrame
    {
        public AlbumFiles()
        {
            
            getContentPane().setLayout(null);
            JTextArea message = new JTextArea("Album files containing N photos require 2N + 1 lines.  The first line is a single integer number representing the number of photos in the album.  The following lines alternate between the filename of a GIF or JPG format photo and a caption describing the photo.  The format for filenames is either relative or absolute.  Relative filename paths are interpreted relative to the directory containing the album file.");
            message.setLineWrap(true);
            message.setWrapStyleWord(true);
            message.setBackground(Color.lightGray);
            
            getContentPane().add(message);
            message.setBounds(10,10,220,200);
            JButton closeButton = new JButton("OK");
            closeButton.addActionListener(new buttonListener());
            getContentPane().add(closeButton);
            closeButton.setBounds(70,210,80,30);
            setTitle("About Album Files");
            setSize(245,275);
            setVisible(true);            
        }
    }
     
     class Progress extends JFrame
     {
        public JLabel progressLabel;
        private JProgressBar pBar; 
        public void SetProgress(int value)
        {
            pBar.setValue(value);
        }
        public Progress(String message)
        {
            getContentPane().setLayout(null);
            progressLabel = new JLabel(message);
            pBar = new JProgressBar(0,100);
            
            getContentPane().add(progressLabel);
            progressLabel.setBounds(10,0,230,30);
            getContentPane().add(pBar);
            pBar.setBounds(10,30,230,20);
            
            setSize(260,90);
            setTitle("Loading Images...");
            setVisible(true);            
        }
    }
    /** Creates new form Album */
    public Album()
    {
      create();
      //loadImages();
    }

    private JPanel titlePanel;
    private JPanel picturePanel;
    private JLabel pictureLabel;
    private JPanel messagePanel;
    private JPanel buttonPanel;
    private JLabel titleLabel;
    private JLabel messageLabel;
    //Image images[];
    private static Album pAlbum;
    private static JFrame frame;
    private JButton pPhoto;
    private JButton nPhoto;
    private String fileNames[];
    private String fileComments[];
    private int nFiles;
    private int currentFileIndex = 0;
    private String albumTitle;
    private boolean startMode = false;
    private String albumDirectory;
    private AlbumFiles aFiles;
    private JPopupMenu popup;
    private boolean popupVisible = false;
    private int viewingMode = 0; // 0 = no album loaded
                                 // 1 = album loaded, normal window
                                 // 2 = album loaded, full screen mode
    private int scaleMode = 0;
    private int indicatorType = 1;
    private Image Images[];
    private Image ScaledImages[];
    private Dimension FullScreenImagePosition[];
    private Dimension FullScreenImageSize[];
    
    private int loadIndex = 0;
    private int lastxSize;
    private int lastySize;
    private AutoWindow FullScreenWindow = null;
    public void openAlbum()
    {
        //System.out.println("x="+picturePanel.getX()+", y="+picturePanel.getY());
        //System.out.println("width="+picturePanel.getWidth()+", height="+picturePanel.getHeight());
        //System.out.println("x="+pictureLabel.getX()+", y="+pictureLabel.getY());
        //System.out.println("width="+pictureLabel.getWidth()+", height="+pictureLabel.getHeight());
        //Create a file chooser
        final JFileChooser fc = new JFileChooser();
        
        ExampleFileFilter filter = new ExampleFileFilter(new String("alb"), "Album Files");
        //filter.addExtenstion(new String("jpg"));
        fc.addChoosableFileFilter(filter);
        String currentDir = System.getProperty("user.dir");
        fc.setCurrentDirectory(new File(currentDir));
        
        //In response to a button click:
        int returnVal = fc.showOpenDialog(this);
        
        if(returnVal == JFileChooser.APPROVE_OPTION)
        {
            currentDir = fc.getCurrentDirectory().toString();
            albumDirectory = currentDir;
            System.setProperty("user.dir",currentDir);
            
            albumTitle = fc.getSelectedFile().getName();
            
            try 
            {
                BufferedReader in = new BufferedReader(new FileReader(fc.getSelectedFile().getPath()));
                popup.removeAll();
                String thisLine;
                thisLine = in.readLine();
                if (thisLine != null)
                {
                    nFiles = Integer.parseInt(thisLine);
                }
                System.out.println("nFiles = "+nFiles);
                fileNames = new String[nFiles];
                fileComments = new String[nFiles];
                PopupMenuItemListener pListener = new PopupMenuItemListener();
                MenuItemListener mListener = new MenuItemListener();
                MyMenuItem mi = new MyMenuItem("Automatic Mode", 5);
                mi.addActionListener(mListener);
                popup.add(mi);
                popup.addSeparator();
                for (int i = 0; i < nFiles; i++)
                {
                    fileNames[i] = in.readLine();
                    System.out.println("fileNames["+i+"] = "+fileNames[i]);
                    fileComments[i] = in.readLine();
                    mi = new MyMenuItem(fileComments[i], i);
                    mi.addActionListener(pListener);
                    popup.add(mi);
                    System.out.println("fileComments["+i+"] = "+fileComments[i]);
                }
                LoadImages();
                
                ScaleImages(picturePanel.getWidth() - 8, picturePanel.getHeight() - 8);
                setViewingMode(1);
                startDisplay();
            }
            catch (Exception e) 
            {
                e.printStackTrace();
            }
            
        }   
    }
    
    public void LoadImages()
    {
        Images = new Image[nFiles];
        String fileName;
        
        messageLabel.setText("Loading Album...");
        
        if (indicatorType == 0)
        {
            frame.setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        }
        
        for (int i = 0; i < nFiles; i++)
        {
            if (fileNames[i].charAt(1)==':')
              fileName = fileNames[i];
            else 
              fileName = albumDirectory + "\\" + fileNames[i];
            Images[i] = Toolkit.getDefaultToolkit().getImage(fileName);
        }
        
        if (indicatorType == 0)
        {
            frame.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        }
    }
    
    class IObserver implements java.awt.image.ImageObserver
    {
        public boolean imageUpdate(java.awt.Image image, int infoflags, int x, int y, int width, int height) 
        {
            //messageLabel.setText("Loading image "+(currentFileIndex+1)+" of "+nFiles+", "+(height * 100 / 500)+"% complete");
            System.out.println("IObserver: currentFileIndex = "+loadIndex+", height = "+height+"y="+y);
            return (height >= 500);
        }   
    }
    
    class FullScreenListener implements ActionListener
    {
        
        public void actionPerformed(java.awt.event.ActionEvent actionEvent) 
        {
            if (FullScreenWindow.CanReceiveCloseEvent == false)
            {
                FullScreenWindow.CanReceiveCloseEvent = true;
                FullScreenWindow.requestFocus();
            }
            
            // .. cycle to next image...
            currentFileIndex = currentFileIndex + 1;
            if (currentFileIndex >= nFiles)
                currentFileIndex = 0;
            
            System.out.println("Full Screen Mode, currentFileIndex = "+currentFileIndex+" nFiles="+nFiles);
            
            ImageIcon image = new ImageIcon(ScaledImages[currentFileIndex]);//fileName);
            FullScreenWindow.pictureLabel.setBounds((int)(FullScreenImagePosition[currentFileIndex].getWidth()),(int)(FullScreenImagePosition[currentFileIndex].getHeight()),(int)(FullScreenImageSize[currentFileIndex].getWidth()),(int)(FullScreenImageSize[currentFileIndex].getHeight()));    
            FullScreenWindow.pictureLabel.setIcon(image);
        }
    }
    
    public void ScaleImages(int width, int height)
    {
        lastxSize = width;
        lastySize = height;
        
        ScaledImages = new Image[nFiles];
        messageLabel.setText("Scaling Images...");
        
        if (indicatorType == 0)
        {
            frame.setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        }
        int hints;
        if (scaleMode == 0)
        {
            hints = Image.SCALE_AREA_AVERAGING;
        }
        else
        {
            hints = Image.SCALE_REPLICATE;
        }
        MediaTracker tracker = new MediaTracker(frame);
        for (int i = 0; i < nFiles; i++)
        {
            ScaledImages[i] = Images[i].getScaledInstance(width,height,hints);
            tracker.addImage(ScaledImages[i],i);
        }
        Progress PBDialog = null;
        if (indicatorType == 2)
        {
            PBDialog = new Progress("Loading Image 1");
        }
        for (loadIndex = 0; loadIndex < nFiles; loadIndex++)
        {
            try
            {
                while (tracker.waitForID(loadIndex,100)==false)
                {
                    int newHeight = ScaledImages[loadIndex].getHeight( new IObserver());
                    int pComplete = (newHeight * 100 / height);
                    String message = "Loading image "+(loadIndex+1)+" of "+nFiles+" "+pComplete+"% complete";
                    if (indicatorType == 2)
                    {
                        PBDialog.SetProgress(pComplete);
                        PBDialog.progressLabel.setText(message);
                        PBDialog.paint(PBDialog.getGraphics());
                    }
                    else
                    {
                        messageLabel.setText(message);
                        messageLabel.paint(messageLabel.getGraphics());
                    }
                    System.out.println("ScaleImages: currentFileIndex = "+loadIndex+", height = "+height);
                    frame.paint(frame.getGraphics());
                    
                }
                //frame.prepareImage(ScaledImages[currentFileIndex], new IObserver());
            }
            catch(Exception e)
            {
                
            }
        }
        if (indicatorType == 0)
        {
            frame.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        }
        else if (indicatorType == 2)
        {
            PBDialog.setVisible(false);
        }
        setViewingMode(1);
    }
    
     public void ScaleImagesForFullScreen()
    {
        ScaledImages = new Image[nFiles];
        FullScreenImagePosition = new Dimension[nFiles];
        FullScreenImageSize = new Dimension[nFiles];
        
        messageLabel.setText("Scaling Images for Full Screen Mode...");
        
        if (indicatorType == 0)
        {
            frame.setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
        }
        int hints;
        if (scaleMode == 0)
        {
            hints = Image.SCALE_AREA_AVERAGING;
        }
        else
        {
            hints = Image.SCALE_REPLICATE;
        }
        MediaTracker tracker = new MediaTracker(frame);
        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        double FRatio = ((double)(screenSize.getWidth())) / ((double)(screenSize.getHeight()));
            
        // .. cycle to next image...
        for (int i = 0; i < nFiles; i++)
        {    
            double w = Images[i].getWidth(new IObserver());
            double h = Images[i].getHeight(new IObserver());
            double IRatio = w / h;
         
            Image ScaledImage;
            int x;
            int y;
            int width;
            int height;
            if (IRatio > FRatio)
            {
                // this is a "wide" image
                x = 0;
                width =  ((int)screenSize.getWidth());
                height = ((int)(((double)width) / IRatio));
                y = ((int)((screenSize.getHeight() - height) / 2));
            }
            else
            {
                // this is a 'tall' image
                y = 0;
                height = (int)screenSize.getHeight();
                width = (int)(((double)height) * IRatio);
                x = (int)((screenSize.getWidth() - width) / 2);
                
            }
            FullScreenImagePosition[i] = new Dimension(x,y);
            FullScreenImageSize[i] = new Dimension(width,height);
            ScaledImages[i] = Images[i].getScaledInstance(width,height,hints);
            tracker.addImage(ScaledImages[i],i);
        }
            
        Progress PBDialog = null;
        if (indicatorType == 2)
        {
            PBDialog = new Progress("Loading Image 1");
        }
        for (loadIndex = 0; loadIndex < nFiles; loadIndex++)
        {
            try
            {
                while (tracker.waitForID(loadIndex,100)==false)
                {
                    int newHeight = ScaledImages[loadIndex].getHeight( new IObserver());
                    int pComplete = (newHeight * 100 / (int)(FullScreenImageSize[loadIndex].getHeight()));
                    String message = "Loading image for full screen "+(loadIndex+1)+" of "+nFiles+" "+pComplete+"% complete";
                    if (indicatorType == 2)
                    {
                        PBDialog.SetProgress(pComplete);
                        PBDialog.progressLabel.setText(message);
                        PBDialog.paint(PBDialog.getGraphics());
                    }
                    else
                    {
                        messageLabel.setText(message);
                        messageLabel.paint(messageLabel.getGraphics());
                    }
                    
                    frame.paint(frame.getGraphics());
                    
                }
                //frame.prepareImage(ScaledImages[currentFileIndex], new IObserver());
            }
            catch(Exception e)
            {
                
            }
        }
        if (indicatorType == 0)
        {
            frame.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        }
        else if (indicatorType == 2)
        {
            PBDialog.setVisible(false);
        }
    }
    
    private void startDisplay()
    {
        startMode = true;    
        titleLabel.setText(albumTitle);
        messageLabel.setText("");
        pPhoto.setVisible(false);
        nPhoto.setText("Start");
        //nPhoto.setVisible(true);
        nPhoto.setEnabled(true);
        pictureLabel.setIcon(null);
        currentFileIndex = 0;
    }
    
    private void setViewingMode(int mode)
    {
        if (mode == 0 || viewingMode == mode)
            return;
        
        if (mode == 2)
        {
            // going to full-screen
            pAlbum.ScaleImagesForFullScreen();
            FullScreenWindow = new AutoWindow(frame);
            FullScreenWindow.setVisible(true);
        }
        else if (mode == 1)
        {
           // closing full-screen   
            if (FullScreenWindow != null)
            {
                FullScreenWindow.setVisible(false);
                FullScreenWindow = null;
                pAlbum.ScaleImages(picturePanel.getWidth() - 8, picturePanel.getHeight() - 8);
                setDisplay();
            }
        }
        viewingMode = mode;
    }
    
    private void setDisplay()
    {
        pPhoto.setEnabled(currentFileIndex > 0);
        nPhoto.setEnabled(currentFileIndex < nFiles - 1);
        titleLabel.setText(albumTitle + " image " + (currentFileIndex + 1) + " of " + nFiles + " (" + fileNames[currentFileIndex] + ")");
        messageLabel.setText(fileComments[currentFileIndex]);
        
     
        ImageIcon image = new ImageIcon(ScaledImages[currentFileIndex]);//fileName);
        pictureLabel.setBounds(4,4,picturePanel.getWidth() - 8, picturePanel.getHeight() - 8);    
        pictureLabel.setIcon(image);
       
    }
    
    public class buttonListener implements ActionListener
    {
        public void actionPerformed(java.awt.event.ActionEvent actionEvent)
        {
            JButton button = (JButton)actionEvent.getSource();
            if (button.getText().compareTo(new String("Previous Photo"))==0)
            {
                System.out.println("Previous Photo");
                pAlbum.previousButton();
            }
            else if (button.getText().compareTo(new String("OK"))==0)
            {
                aFiles.setVisible(false);
            }
            else
            {
                if (startMode == true)
                {
                    currentFileIndex = 0;
                    startMode = false;
                    pPhoto.setVisible(true);
                    nPhoto.setText("Next Photo");
                    setDisplay();
                }
                else 
                {
                    pAlbum.nextButton();
                }
                System.out.println("Next Photo");
            }
        }
    }
     
    class MyKeyListener implements KeyListener
    {
        public void keyPressed(KeyEvent e)
        {
            if (viewingMode == 2)
            {
                pAlbum.setViewingMode(1);
            }
            
            //System.out.println("Key pressed...");
            int a = e.getModifiers();
            int b = e.getKeyCode();
            System.out.println("a="+a+"b="+b);
            if (a==2 && b == 65)
            {
                AboutDialog dDlg = new AboutDialog();
                dDlg.setVisible(true);
            }
            else if (a==2 && b == 70)
            {
                aFiles = new AlbumFiles();
            }
            if (a==2 && b == 79)
            {
                // call open
                pAlbum.openAlbum();
            }
            else if(a == 2 && b == 88)
            {
                System.exit(0);
            }
            if (viewingMode != 0)
            {
                if (a==0 && b==37)
                {
                    //left
                    pAlbum.previousButton();
                }
                if (a==0 && b==39)
                {
                    //right
                    pAlbum.nextButton();
                }
            }
        }
        
        public void keyReleased(java.awt.event.KeyEvent keyEvent) {
        }
        
        public void keyTyped(java.awt.event.KeyEvent keyEvent) {
        }
        
    }
        
    
    class PopupMenuMonitor implements PopupMenuListener
    {
        public void popupMenuCanceled(javax.swing.event.PopupMenuEvent popupMenuEvent) {
        }
        
        public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent popupMenuEvent) {
        }
        
        public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent popupMenuEvent) {
        }
        
    }
    
    class WindowResizer extends java.awt.event.ComponentAdapter
    {
        public void componentResized(ComponentEvent e)
        {
            if (viewingMode != 0)
            {
                
                if (java.lang.Math.abs(picturePanel.getWidth() - 8 - lastxSize) > 5 || 
                    java.lang.Math.abs(picturePanel.getWidth() - 8 - lastySize) > 5)
                {
                    pAlbum.ScaleImages(picturePanel.getWidth() - 8, picturePanel.getHeight() - 8);
                    setViewingMode(1);
                    setDisplay();
                }
            }
        }
    }
    protected void create()
    {
      popup = new JPopupMenu("Popup Menu");
      popup.setLabel("Popup Menu");
      
      popup.setInvoker(frame);
      popup.addPopupMenuListener(new PopupMenuMonitor());
      MouseListener mL = new MouseAdapter()
      {
        public void mouseClicked(MouseEvent e)
        {
            popupVisible = !popupVisible;
            if (popupVisible)
            {
                popup.show(frame,e.getX(),e.getY());
            }
            else
            {
                popup.setVisible(false);
            }
        }
      };  
      frame.addMouseListener(mL);
      add(popup);
      
      frame.addKeyListener(new MyKeyListener());
      setLayout(new BorderLayout());
      
      titlePanel = new JPanel();
      titleLabel = new JLabel("Photo Album Program - No Album Loaded");
      titlePanel.add(titleLabel);
      titlePanel.setBounds(0,0,500,30);
      
      picturePanel = new JPanel();
      picturePanel.setLayout(null);
      picturePanel.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
      
      pictureLabel = new JLabel();
      pictureLabel.setSize(500,500);
      picturePanel.add(pictureLabel);
      pictureLabel.setBounds(4,4,500,500);
      picturePanel.setBounds(0,30,508,508);
      picturePanel.addComponentListener(new WindowResizer());
      
      messagePanel = new JPanel();
      messagePanel.setLayout(new BorderLayout());
      JPanel messageHolder = new JPanel();
      
      messageLabel = new JLabel("No Image Loaded - Choose Open from the File Menu");
      messageHolder.add(messageLabel);
      
      messagePanel.add(messageHolder, BorderLayout.NORTH);
      //messagePanel.setBounds(0,540,500,30);
      
      buttonPanel = new JPanel();
      pPhoto = new JButton("Previous Photo");
      pPhoto.addActionListener(new buttonListener());
      nPhoto = new JButton("Start");
      nPhoto.addActionListener(new buttonListener());
      buttonPanel.add(pPhoto);
      pPhoto.setBounds(191,0,120,30);
      nPhoto.setBounds(318,0,100,30);
      buttonPanel.add(nPhoto);
      pPhoto.setVisible(false);
      //nPhoto.setVisible(false);
      nPhoto.setEnabled(false);
      buttonPanel.setBounds(0,570,500,35);
      
      messagePanel.add(buttonPanel, BorderLayout.SOUTH);
      add(titlePanel, BorderLayout.NORTH);
      add(picturePanel, BorderLayout.CENTER);
      add(messagePanel, BorderLayout.SOUTH);
      //add(buttonPanel, BorderLayout.SOUTH);
      createMenus();
    }
    
    public Dimension getPreferredSize()
    {
        return new Dimension(512,608);
    }

    public Dimension getMinimumSize()
    {
        return getPreferredSize();
    }

    public static void main(String [] args)
    {
        frame = new JFrame("Album for CS 5100");
        pAlbum = new Album();
        frame.getContentPane().add(pAlbum);
        frame.pack();
        frame.setVisible(true);
       
    }
    
    public void previousButton()
    {
        if (currentFileIndex > 0)
        {
            currentFileIndex--;
            setDisplay();
        }
    }
    
    public void nextButton()
    {
        if (currentFileIndex < nFiles - 1)
        {
            currentFileIndex++;
            setDisplay();
        }
    }
    
    private void createMenus()
    {
        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic('F');
        MyMenuItem mi11 = new MyMenuItem("Open Album (Ctrl+O)",1);
        
        //mi11.setAccelerator(new KeyStroke('O',java.awt.Event.CTRL_MASK));
        
        MenuItemListener miListener = new MenuItemListener();
        mi11.addActionListener(miListener);
        MyMenuItem mi12 = new MyMenuItem("Exit (Ctrl+X)",2);
        mi12.addActionListener(miListener);
        fileMenu.add(mi11);
        fileMenu.addSeparator();
        fileMenu.add(mi12);

        RadioMenuItemListener rbListener = new RadioMenuItemListener();
        JMenu scalingMenu = new JMenu("Scales");  //  average, replicate
        scalingMenu.setMnemonic('S');
        MyRadioButtonItem rbmi1 = new MyRadioButtonItem("Average",true,1);
        MyRadioButtonItem rbmi2 = new MyRadioButtonItem("Replicate",false,2);
        rbmi1.addActionListener(rbListener);
        rbmi2.addActionListener(rbListener);
        ButtonGroup bg1 = new ButtonGroup();
        bg1.add(rbmi1);
        bg1.add(rbmi2);
        scalingMenu.add(rbmi1);
        scalingMenu.add(rbmi2);
        
        JMenu trackingMenu = new JMenu("Tracking"); // cursor, label, progress bar
        trackingMenu.setMnemonic('T');
        rbmi1 = new MyRadioButtonItem("Cursor",false,3);
        rbmi2 = new MyRadioButtonItem("Label",true,4);
        MyRadioButtonItem rbmi3 = new MyRadioButtonItem("Progress Bar",false,5);
        rbmi1.addActionListener(rbListener);
        rbmi2.addActionListener(rbListener);
        rbmi3.addActionListener(rbListener);
        ButtonGroup bg2 = new ButtonGroup();
        bg2.add(rbmi1);
        bg2.add(rbmi2);
        bg2.add(rbmi3);
        trackingMenu.add(rbmi1);
        trackingMenu.add(rbmi2);
        trackingMenu.add(rbmi3);
        
        JMenu optionsMenu = new JMenu("Help");
        optionsMenu.setMnemonic('H');
        MyMenuItem mi21 = new MyMenuItem("About (Ctrl+A)...",3);
        mi21.addActionListener(miListener);
        MyMenuItem mi22 = new MyMenuItem("Album Files (Ctrl+F)...",4);
        mi22.addActionListener(miListener);

        optionsMenu.add(mi21);
        optionsMenu.add(mi22);

        JMenuBar menuBar = new JMenuBar();
        menuBar.add(fileMenu);
        menuBar.add(scalingMenu);
        menuBar.add(trackingMenu);
        menuBar.add(optionsMenu);
        frame.setJMenuBar(menuBar);
    }
    
    class PopupMenuItemListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            if (viewingMode == 2)
            {
                pAlbum.setViewingMode(1);
                return;
            }
            
            if (viewingMode == 1)
            {
                currentFileIndex = ((MyMenuItem)e.getSource()).id;
                pAlbum.setDisplay();
            }
        }
    }
    class MenuItemListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            switch (((MyMenuItem)e.getSource()).id)
            {
            case 1:
                pAlbum.openAlbum();
            break;
            case 2:
                System.exit(0);
            break;
            case 3:
                AboutDialog dDlg = new AboutDialog();
                dDlg.setVisible(true);
            break;
            case 4:
                aFiles = new AlbumFiles();
            break;
            case 5: //Automatic Mode
                pAlbum.setViewingMode(2);
                //System.exit(0);
            break;
            }
        }
    }
    class RadioMenuItemListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            switch (((MyRadioButtonItem)e.getSource()).id)
            {
            case 1:
                scaleMode = 0;
            break;
            case 2:
                scaleMode = 1;
            break;
            case 3:
                indicatorType = 0;
            break;
            case 4:
                indicatorType = 1;
            break;
            case 5: 
                indicatorType = 2;
            break;
            }
            System.out.println("scaleMode="+scaleMode);
            System.out.println("indicatorType="+indicatorType);
        }
    }
    class MyMenuItem extends JMenuItem
    {
        public int id;
        public MyMenuItem(String name, int Id)
        {
            super(name);
            id = Id;
        }
    }
    class MyRadioButtonItem extends JRadioButtonMenuItem
    {
        public int id;
        public MyRadioButtonItem(String name, boolean isSelected, int Id)
        {
            super(name, isSelected);
            id = Id;
        }
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    private void initComponents() {//GEN-BEGIN:initComponents
        
        setLayout(new java.awt.BorderLayout());
        
    }//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

}
