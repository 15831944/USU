// AFXClockPpg.cpp : Implementation of the CAFXClockPropPage property page class.

#include "stdafx.h"
#include "AFXClock.h"
#include "AFXClockPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CAFXClockPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CAFXClockPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CAFXClockPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CAFXClockPropPage, "AFXCLOCK.AFXClockPropPage.1",
	0x4e54d369, 0xc529, 0x11d4, 0xb3, 0x98, 0, 0xa0, 0xcc, 0x54, 0x8b, 0xe4)


/////////////////////////////////////////////////////////////////////////////
// CAFXClockPropPage::CAFXClockPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CAFXClockPropPage

BOOL CAFXClockPropPage::CAFXClockPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_AFXCLOCK_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CAFXClockPropPage::CAFXClockPropPage - Constructor

CAFXClockPropPage::CAFXClockPropPage() :
	COlePropertyPage(IDD, IDS_AFXCLOCK_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CAFXClockPropPage)
	m_military = FALSE;
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CAFXClockPropPage::DoDataExchange - Moves data between page and properties

void CAFXClockPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CAFXClockPropPage)
	DDP_Check(pDX, IDC_CHECK1, m_military, _T("Military") );
	DDX_Check(pDX, IDC_CHECK1, m_military);
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CAFXClockPropPage message handlers
