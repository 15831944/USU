#if !defined(AFX_AFXCLOCKPPG_H__4E54D378_C529_11D4_B398_00A0CC548BE4__INCLUDED_)
#define AFX_AFXCLOCKPPG_H__4E54D378_C529_11D4_B398_00A0CC548BE4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// AFXClockPpg.h : Declaration of the CAFXClockPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CAFXClockPropPage : See AFXClockPpg.cpp.cpp for implementation.

class CAFXClockPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CAFXClockPropPage)
	DECLARE_OLECREATE_EX(CAFXClockPropPage)

// Constructor
public:
	CAFXClockPropPage();

// Dialog Data
	//{{AFX_DATA(CAFXClockPropPage)
	enum { IDD = IDD_PROPPAGE_AFXCLOCK };
	BOOL	m_military;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CAFXClockPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AFXCLOCKPPG_H__4E54D378_C529_11D4_B398_00A0CC548BE4__INCLUDED)
