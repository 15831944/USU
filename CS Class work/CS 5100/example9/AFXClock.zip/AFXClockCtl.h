#if !defined(AFX_AFXCLOCKCTL_H__4E54D376_C529_11D4_B398_00A0CC548BE4__INCLUDED_)
#define AFX_AFXCLOCKCTL_H__4E54D376_C529_11D4_B398_00A0CC548BE4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// AFXClockCtl.h : Declaration of the CAFXClockCtrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CAFXClockCtrl : See AFXClockCtl.cpp for implementation.

class CAFXClockCtrl : public COleControl
{
	DECLARE_DYNCREATE(CAFXClockCtrl)

// Constructor
public:
	CAFXClockCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAFXClockCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CAFXClockCtrl();

	DECLARE_OLECREATE_EX(CAFXClockCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CAFXClockCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CAFXClockCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CAFXClockCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CAFXClockCtrl)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CAFXClockCtrl)
	CString m_time;
	afx_msg void OnTimeChanged();
	BOOL m_military;
	afx_msg void OnMilitaryChanged();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CAFXClockCtrl)
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CAFXClockCtrl)
	dispidTime = 1L,
	dispidMilitary = 2L,
	//}}AFX_DISP_ID
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AFXCLOCKCTL_H__4E54D376_C529_11D4_B398_00A0CC548BE4__INCLUDED)
