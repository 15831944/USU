// AFXClockCtl.cpp : Implementation of the CAFXClockCtrl ActiveX Control class.

#include "stdafx.h"
#include "AFXClock.h"
#include "AFXClockCtl.h"
#include "AFXClockPpg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CAFXClockCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CAFXClockCtrl, COleControl)
	//{{AFX_MSG_MAP(CAFXClockCtrl)
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_EDIT, OnEdit)
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CAFXClockCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CAFXClockCtrl)
	DISP_PROPERTY_NOTIFY(CAFXClockCtrl, "Time", m_time, OnTimeChanged, VT_BSTR)
	DISP_PROPERTY_NOTIFY(CAFXClockCtrl, "Military", m_military, OnMilitaryChanged, VT_BOOL)
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CAFXClockCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CAFXClockCtrl, COleControl)
	//{{AFX_EVENT_MAP(CAFXClockCtrl)
	EVENT_STOCK_CLICK()
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CAFXClockCtrl, 1)
	PROPPAGEID(CAFXClockPropPage::guid)
END_PROPPAGEIDS(CAFXClockCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CAFXClockCtrl, "AFXCLOCK.AFXClockCtrl.1",
	0x4e54d368, 0xc529, 0x11d4, 0xb3, 0x98, 0, 0xa0, 0xcc, 0x54, 0x8b, 0xe4)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CAFXClockCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DAFXClock =
		{ 0x4e54d366, 0xc529, 0x11d4, { 0xb3, 0x98, 0, 0xa0, 0xcc, 0x54, 0x8b, 0xe4 } };
const IID BASED_CODE IID_DAFXClockEvents =
		{ 0x4e54d367, 0xc529, 0x11d4, { 0xb3, 0x98, 0, 0xa0, 0xcc, 0x54, 0x8b, 0xe4 } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwAFXClockOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CAFXClockCtrl, IDS_AFXCLOCK, _dwAFXClockOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CAFXClockCtrl::CAFXClockCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CAFXClockCtrl

BOOL CAFXClockCtrl::CAFXClockCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegInsertable | afxRegApartmentThreading to afxRegInsertable.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_AFXCLOCK,
			IDB_AFXCLOCK,
			afxRegInsertable | afxRegApartmentThreading,
			_dwAFXClockOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CAFXClockCtrl::CAFXClockCtrl - Constructor

CAFXClockCtrl::CAFXClockCtrl()
{
	InitializeIIDs(&IID_DAFXClock, &IID_DAFXClockEvents);
	m_military = FALSE;
}


/////////////////////////////////////////////////////////////////////////////
// CAFXClockCtrl::~CAFXClockCtrl - Destructor

CAFXClockCtrl::~CAFXClockCtrl()
{
	// TODO: Cleanup your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CAFXClockCtrl::OnDraw - Drawing function

void CAFXClockCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	// TODO: Replace the following code with your own drawing code.
	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
	pdc->ExtTextOut(0,0,ETO_OPAQUE, rcBounds, m_time, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CAFXClockCtrl::DoPropExchange - Persistence support

void CAFXClockCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	PX_String(pPX, "Time", m_time, "January 1, 1900 00:00:00");
}


/////////////////////////////////////////////////////////////////////////////
// CAFXClockCtrl::OnResetState - Reset control to default state

void CAFXClockCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CAFXClockCtrl::AboutBox - Display an "About" box to the user

void CAFXClockCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_AFXCLOCK);
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CAFXClockCtrl message handlers

void CAFXClockCtrl::OnTimeChanged() 
{
	SetModifiedFlag();
}

void CAFXClockCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CTime time = CTime::GetCurrentTime();
	if (!m_military) m_time = time.Format("%B %d, %Y  %I:%M:%S");
	else m_time = time.Format("%B %d, %Y  %H:%M:%S");
	Invalidate();
	
	COleControl::OnLButtonDown(nFlags, point);
}

void CAFXClockCtrl::OnMilitaryChanged() 
{
	// TODO: Add notification handler code

	SetModifiedFlag();
}
