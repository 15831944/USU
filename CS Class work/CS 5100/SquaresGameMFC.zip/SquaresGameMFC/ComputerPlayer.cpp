// omputerPlayer.cpp: implementation of the ComputerPlayer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SquaresGame.h"
#include "ComputerPlayer.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ComputerPlayer::ComputerPlayer()
{

}

ComputerPlayer::~ComputerPlayer()
{

}

