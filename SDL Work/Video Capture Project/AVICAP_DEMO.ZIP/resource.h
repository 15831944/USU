//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AviCapTest.rc
//
#define IDD_ABOUTBOX                    100
#define CG_IDD_PROGRESS                 102
#define CG_IDS_PROGRESS_CAPTION         103
#define IDR_MAINFRAME                   128
#define IDR_AVICAPTYPE                  129
#define IDD_DIALOG1                     130
#define IDD_DIALOG2                     131
#define IDC_EDIT1                       1000
#define IDC_FORMATLIST                  1001
#define IDC_RESOLUTION                  1002
#define CG_IDC_PROGDLG_PROGRESS         1003
#define CG_IDC_PROGDLG_PERCENT          1004
#define CG_IDC_PROGDLG_STATUS           1005
#define ID_FILE_PREVIEW                 32771
#define ID_FILE_FORMAT                  32772
#define ID_FILE_SOURCE                  32773
#define ID_FILE_DISPLAY                 32775
#define ID_FILE_DRIVER                  32776
#define ID_VIEW_AUTOSIZE                32777
#define ID_VIEW_DRAW                    32778
#define ID_FILEENHCTL                   32779
#define ID_VIEW_PLUS                    32780
#define ID_VIEW_MINUS                   32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
