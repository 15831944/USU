// DataTransfer.cpp : implementation file
//

#include "stdafx.h"
#include "lada control module.h"
#include "DataTransfer.h"

#include "LADA Control ModuleDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString BrowseForFolder(LPCSTR lpszTitle, UINT nFlags = 0, LPCITEMIDLIST pidlRoot = NULL, CWnd *parentWnd = NULL);
extern CFont smallRussianArial;

/////////////////////////////////////////////////////////////////////////////
// CDataTransfer dialog


CDataTransfer::CDataTransfer(CLADAControlModuleDoc * doc, CWnd* pParent /*=NULL*/)
	: CDialog(CDataTransfer::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDataTransfer)
	m_DestinationFolder = _T("");
	m_SourceFolder = _T("");
	m_BmpToJpg = FALSE;
	m_ArchiveFiles = FALSE;
	m_PictureFiles = FALSE;
	m_RealTime = FALSE;
	//}}AFX_DATA_INIT
	pDoc = doc;
	m_PtrFileNames = NULL;
	Expanded = FALSE;
}


void CDataTransfer::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDataTransfer)
	DDX_Control(pDX, IDC_PCMCIA, m_Pcmcia);
	DDX_Control(pDX, IDC_OTHER, m_Other);
	DDX_Control(pDX, IDC_FLOPPY, m_Floppy);
	DDX_Control(pDX, IDC_NUM_SELECTED, m_NumSelected);
	DDX_Check(pDX, IDC_BMPTOJPG, m_BmpToJpg);
	DDX_Text(pDX, IDC_DESTINATION_FOLDER, m_DestinationFolder);
	DDX_Text(pDX, IDC_SOURCE_FOLDER, m_SourceFolder);
	DDX_Check(pDX, IDC_ARCHIVE_FILES, m_ArchiveFiles);
	DDX_Check(pDX, IDC_PICTURE_FILES, m_PictureFiles);
	DDX_Check(pDX, IDC_REAL_TIME_FILES, m_RealTime);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDataTransfer, CDialog)
	//{{AFX_MSG_MAP(CDataTransfer)
	ON_BN_CLICKED(IDC_BROWSE_DESTINATION, OnBrowseDestination)
	ON_BN_CLICKED(IDC_SET_DEFAULT, OnSetDefault)
	ON_BN_CLICKED(IDC_NEW_FILES_ONLY, OnNewFilesOnly)
	ON_BN_CLICKED(IDC_ALL_FILES, OnAllFiles)
	ON_BN_CLICKED(IDC_VIEW_FILES, OnViewFiles)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDataTransfer message handlers

void CDataTransfer::OnBrowseDestination() 
{
	// TODO: Add your control notification handler code here
	CString oldFolder = m_DestinationFolder;
	m_DestinationFolder = BrowseForFolder("Select Destination Folder for Data Files");
	if (m_DestinationFolder != "")
		UpdateData(FALSE);
	else
		m_DestinationFolder = oldFolder;
}

void CDataTransfer::OnSetDefault() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	//pDoc->DestinationFolder = m_DestinationFolder;

}

void CDataTransfer::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();

	CDialog::OnOK();
}

void CDataTransfer::OnNewFilesOnly() 
{
	// TODO: Add your control notification handler code here
	if (m_NewOnly == FALSE)
	{
		m_NewOnly = TRUE;
		PrepareFileList();
	}
}

void CDataTransfer::OnAllFiles() 
{
	// TODO: Add your control notification handler code here
	if (m_NewOnly == TRUE)
	{
		m_NewOnly = FALSE;
		PrepareFileList();
	}
}

void CDataTransfer::PrepareFileList()
{
	CButton *b1 = (CButton *)GetDlgItem(IDC_NEW_FILES_ONLY);
	CButton *b2 = (CButton *)GetDlgItem(IDC_ALL_FILES);
	b1->SetCheck(m_NewOnly);
	b2->SetCheck(!m_NewOnly);
	GetFileList();
	char n[5];
	wsprintf(n,"%i",m_nSelected);
	m_NumSelected.SetWindowText(n);
}

void CDataTransfer::GetFileList()//=TRUE
{
	if (m_PtrFileNames)
		delete [] m_PtrFileNames;
	m_PtrFileNames = new char[1000][MAX_PATH];
	m_nSelected = 0;

	WIN32_FIND_DATA FindFileData;
	HANDLE hFind;
	CString FileSearchInfo = m_SourceFolder + "\\*.dat";

	hFind = FindFirstFile(FileSearchInfo,&FindFileData);
	
	if (Expanded)
		FileListWindow->ResetContent();

	if (hFind != INVALID_HANDLE_VALUE)
	{
		do
		{
			if (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE ||
				!m_NewOnly)
			{
				//char * thisFilePtr = new char[strlen(FindFileData.cFileName)];
				//strcpy(thisFilePtr, FindFileData.cFileName );
				strcpy(m_PtrFileNames[m_nSelected++], FindFileData.cFileName );
				// add thisFilePtr to some linked list
				if (Expanded)
					FileListWindow->AddString(FindFileData.cFileName);
			}
		}
		while (FindNextFile(hFind, &FindFileData));
	}

}

BOOL CDataTransfer::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	//m_AddToZip = FALSE;//pDoc->AddDataToZip;
	//m_ArchiveName = "LadaData.zip";//pDoc->ZipName;
	m_BmpToJpg = TRUE;
	m_DestinationFolder = "F:\\LADA Data";//pDoc->DestinationFolder;
	m_SourceFolder = pDoc->dataFolder;
	m_NewOnly = TRUE;
	PrepareFileList();
	char n[5];
	wsprintf(n,"%i",m_nSelected);
	m_NumSelected.SetWindowText(n);
	Expanded = FALSE;
	FloppyButton.AutoLoad(IDC_FLOPPY,this);
	PCMCIAButton.AutoLoad(IDC_PCMCIA,this);
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDataTransfer::OnViewFiles() 
{
	// TODO: Add your control notification handler code here
	if (m_nSelected || Expanded)
	{
		CRect rect;
		GetWindowRect(&rect);
		int ExpansionSize = 250;
			
		if (Expanded)
		{
			FileListWindow->DestroyWindow();
			delete FileListWindow;
			SetWindowPos(this,0,0,
				rect.Width() - ExpansionSize, rect.Height(), 
				SWP_FRAMECHANGED | SWP_NOMOVE | 
				SWP_SHOWWINDOW | SWP_NOZORDER );

			Expanded = FALSE;
			GetDlgItem(IDC_VIEW_FILES)->SetWindowText("View Files");
		}
		else
		{
			GetDlgItem(IDC_VIEW_FILES)->SetWindowText("Hide Files");
			int borderSize = 20;
			int left = rect.Width() - 20;
			int right = rect.Width() + ExpansionSize - borderSize;
			int top = borderSize;
			int bottom = rect.Height() - borderSize;
			CRect ListRect(left,top,right,bottom);
			SetWindowPos(this,0,0,
				rect.Width() + ExpansionSize, rect.Height(), 
				SWP_FRAMECHANGED | SWP_NOMOVE | 
				SWP_SHOWWINDOW | SWP_NOZORDER );
			Expanded = TRUE;
			FileListWindow = new CListBox();
			DWORD nID = 5000;	//WS_CHILD|WS_VISIBLE|LBS_STANDARD|WS_HSCROLL
			FileListWindow->Create(WS_CHILD|WS_VISIBLE|LBS_STANDARD|WS_HSCROLL|WS_DISABLED,ListRect,this,IDC_TEMP_FILEVIEW);
			FileListWindow->SetFont(&smallRussianArial,FALSE);
			for(int i = 0; i < m_nSelected ; i++)
			{
				FileListWindow->AddString(m_PtrFileNames[i]);
			}
		}
	}
	else
	{


	}
}
