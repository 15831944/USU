#if !defined(AFX_DATATRANSFER_H__7849C0A0_9080_11D4_8303_87ACE5C34B86__INCLUDED_)
#define AFX_DATATRANSFER_H__7849C0A0_9080_11D4_8303_87ACE5C34B86__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataTransfer.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataTransfer dialog
class CLADAControlModuleDoc;

class CDataTransfer : public CDialog
{
// Construction
public:
	CBitmapButton FloppyButton;
	CBitmapButton PCMCIAButton;
	int m_nSelected;
	BOOL m_NewOnly;
	CDataTransfer(CLADAControlModuleDoc *doc, CWnd* pParent = NULL); // standard constructor
	void GetFileList();
	CLADAControlModuleDoc * pDoc;
	void PrepareFileList();
	char (* m_PtrFileNames)[MAX_PATH];
	CListBox *FileListWindow;
	BOOL Expanded;
// Dialog Data
	//{{AFX_DATA(CDataTransfer)
	enum { IDD = IDD_DATA_TRANSFER };
	CButton	m_Pcmcia;
	CButton	m_Other;
	CButton	m_Floppy;
	CStatic	m_NumSelected;
	BOOL	m_BmpToJpg;
	CString	m_DestinationFolder;
	CString	m_SourceFolder;
	BOOL	m_ArchiveFiles;
	BOOL	m_PictureFiles;
	BOOL	m_RealTime;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataTransfer)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataTransfer)
	afx_msg void OnBrowseDestination();
	afx_msg void OnSetDefault();
	virtual void OnOK();
	afx_msg void OnNewFilesOnly();
	afx_msg void OnAllFiles();
	virtual BOOL OnInitDialog();
	afx_msg void OnViewFiles();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATATRANSFER_H__7849C0A0_9080_11D4_8303_87ACE5C34B86__INCLUDED_)
