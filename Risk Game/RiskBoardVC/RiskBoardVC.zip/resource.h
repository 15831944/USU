//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RiskBoardVC.rc
//
#define IDS_RISKBOARDVC                 1
#define IDB_RISKBOARDVC                 1
#define IDS_RISKBOARDVC_PPG             2
#define ID_DO_SCROLLING_EVENT           101
#define IDS_RISKBOARDVC_PPG_CAPTION     200
#define IDD_PROPPAGE_RISKBOARDVC        200
#define IDB_LARGEBOARD                  201
#define IDB_BLACK_MAN                   202
#define IDB_BLUE_MAN                    203
#define IDB_GREEN_MAN                   204
#define IDB_MASK_MAN                    205
#define IDB_PURPLE_MAN                  206
#define IDB_RED_MAN                     207
#define IDB_YELLOW_MAN                  208
#define BOARDDAT                        209
#define COUNTRYLIST                     210

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        212
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
