// MyDialog.cpp : implementation file
//

#include "stdafx.h"
#include "RiskMon.h"
#include "MyDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
extern CMyDialog *pdlg;
#endif

